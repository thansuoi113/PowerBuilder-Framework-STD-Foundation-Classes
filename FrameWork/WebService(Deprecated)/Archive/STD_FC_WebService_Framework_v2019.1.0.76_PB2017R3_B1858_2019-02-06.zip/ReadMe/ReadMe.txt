
Software Tool & Die Inc
Web Service - Internet Information System (IIs) Foundation Classes

=================================  HISTORY   ==============================
Release 2019.1.0.76 - February 06, 2019 GA    - Major Release (2018R2)

Release 2018.1.0.72 - August 21, 2018 GA     - Major Release (2018R2)
Release 2018.1.0.68 - June 12, 2018 GA       - Major Release (2018R1) 

Release 2017.2.0.65 - July 07, 2017 GA       - Major Release (2017R2) 
Release 2017.1.0.59 - May 05, 2017 GA        - Major Release (2017R1) 

Release 2016.2.0.58 - June 23, 2016 GA       - Service Pack  (2016R2)
Release 2016.1.0.55 - April 26, 2016 GA      - Major Release (2016R1) 

Release 2015.3.1.52 - October 06, 2015 GA    - EBF Pack      (2015R3-1)
Release 2015.3.0.51 - September 30, 2015 GA  - Service Pack  (2015R3) 
Release 2015.2.0.45 - May   30, 2015   GA    - Service Pack  (2015R2) 
Release 2015.1.0.40 - April 30, 2015   GA    - Major Release (2015R1)

---------  Release Numbering Changed  - YYYY.Rel.Fix.Build ----------------

Release 2.3.0.32 - January 29, 2015    GA    - Service Pack #3
Release 2.2.2.23 - December 16, 2014   GA    - EBF#2
Release 2.2.1.22 - December 9, 2014    GA    - EBF#1
Release 2.2.0.21 - December 4, 2014    SP    - Service Pack #2
Release 2.1.0.14 - July 11, 2014       SP    - Service Pack #1
Release 2.0.0.01 - June 5, 2014        GA    - Major Release!

Release 1.1.2.11  - April 24, 2014     SP    - Service Pack #2
Release 1.1.1.07  - January 12, 2013   SP    - Service Pack #1
Release 1.1.0.01  - November 5, 2013   GA    - Update
Release 1.0.0.01  - March 5, 2013      GA    - Port of EAServer FC's to IIs


=================================  FORWARD   ==============================

(STD PB IIs FC)

 All Developers;

	Welcome to the the Software Tool & Die (STD) web service development enhancement Foundation Classes (FC) for PowerBuilder (PB). This is a set of "intelligent" ancestor objects for PB release 12.6.0 (build 4108) and higher! The FC's have been designed over a period of years and are presented here as "freeware" (please see the enclosed STD General license Agreement) and on an "as is" basis. The STD IIs FC's are a port of the EAServer compliment originally designed for the PocketPC and a hybrid adaptation of Web.PB and ASP/ASP.net alignment. The interesting thing about these classes is the "small" footprint and exceptional speed at which it operates. On one IIs Server, where every CPU cycle is precious, the FC's have proven heir worth in EAServer since 1998. Now you can enjoy a "Light" version of the PFC for Web Services without the heavy learning curve, high compile and run time overhead. The STD IIs FC's will compile to less than 100K (PBD form) compared to nearly 12M for the Sybase PFC's which can not even be used for IIs based Web Services!

 	The STD IIs FC's represent a significant enhancement to the way a PB developer works (productivity), the capabilities of PB, and optimization/leverage of the IIs Server (Application Server) System. These FC's were developed with the PowerBuilder (PB) PFC in mind, but ... have been made easier to use, more efficient (less overhead), more intuitive, parameter driven and more "Object Oriented". Initial testing with one IIs Server has shown this architecture can easily support up to concurrent 1,000 sessions per minute or more!

	Each release of the STD IIs FC's is geared to it's equivalent PB release! In each PB release there are significant changes. For example HTML rendering of web pages and run time behavior between Build nnnn to Build xxxx,  that we would recommend ONLY using this version of the STD IIs FC's with your PB Build! If you want to use the FC's with a lower Build number, you may experience some weird "real estate" scenarios. These will have to be adjusted for when you migrate to your production build version. But, if do not mind that, it should be a minor realignment effort.

	The STD Fc's come with a "WorkSpace", "Target" and dummy "Application Object". These have been provided to allow you regenerate the objects. It is expected that the PB web service developer will use this set of BASE and ABSTRACT ancestor objects for their new application development. To keep the FC overhead small, it is expected that the PPB developer will copy and RENAME the FC library to their own project. For example: if you were developing a Help Desk System you might copy the "STD_FC_IIs_Base.pbl" and rename it to "HDS_Base.pbl". Then treat the objects in "HDS_Base.pbl" as you would the "PFE" layer of the PB PFC. This "HDS_Base.pbl" should compile into a ".PKD" file of about 500K which compliments the any device with a small foot print!

	I have not had the extensive time to document the STD FC's objects other that in the "oe_Documentation" events and throughout the general code. So please review these areas fully to understand the object(s) behavior. STD also recommends downloading the sample "Web Service Test" application built from the STD IIs FC's, as another aid in assimilating the FC learning curve. Both the STD FC's and the "WS Test" system will be enhanced together to reflect the intended use of the Base / Abstract classes.

	From the GUI point of view, the STD FC's can be used to build any JSP, ASP, PHP, CFM, etc web applciation basing the logic and HTML generation on Sybase "Web" DataWindow technology. From the various demonstration applications, you will see the ability to build. Since this FC was developed in Canada's National capital, it was architected to support multiple languages. Of course Canada supports either French or English, but the STD FC's were built to support any combination of languages, either now or in the future. The general approach is "static" language switching (where the user picks the language at "start up" time) but the STD FC's have also been enhanced to be "dynamic" language capable as well.

	STD would like to recognize it's Alpha and Beta testers for the STD FC's. This has now included five major Canadian Government Departments and numerous private corporations around North America. This has led to a more polished 1st release of the FC's. It is hoped that as other various parties develop code using the STD FC's or, PB developers have functional requirements not yet supported, they will funnel these back to the author for inclusion in the next release! This marks a mile stone for me as an original Beta tester on PB release 0.8 (Nov 1989) to PB 12.1.x and now 12.6.x in 2017 without missing a Beta cycle. Please enjoy the STD IIs FC's for PB web service creation. I hope you find them as fun to use as I had in building them! 


Regards;

Chris Pollach (Author STD FC's)
President - Software Tool & Die Inc.
aka: Great White North Technical Evangelist (have you hugged your "DataWindow" today?)
e-Mail:	Chris.Pollach@NCF.ca
Website:  http://www.softdie.net
Blog: http://chrispollach.blogspot.com
PBDJ: http://chrispollach.sys-con.com
SourceForge: http://sourceforge.net/projects/stdfndclass


=================================  CHANGE DETAIL HISTORY   ==============================

Release 2019.1.0.76 Service Pack (2019R1) ... February 06, 2019 (GA) PB 17.0.0 Build 1858 (PB2017R3)

1)	Synchronized API declarations from the Integrated framework (2019.1.0.124) into "nc_master"
2)	Revised framework version to 2019.1.0.76 in "nc_ws_master"
3)	Revised "ns_sqlca_master" object class to support Rollback or Commit on "Disconnect" (as per Integrated framework)


Release 2018.2.0.72 Service Pack (2018R1) ... August 21, 2018 (GA) PB 17.0.0 Build 1858 (PB2017R3)

1)	Migrated the Web Service framework from PB2017R2 to PB2017R3 Universal Edition.
2) 	Changed the release number in nc_ws_master to 2018.2.0.72
3)	Added & Revised API declarations as per the Integrated framework (syncronized) in "nc_master".
4)	Added System.IO.dll .Net assembly reference to the Target
5)	Added System.IO.Compression.dll .Net assembly reference to the Target
6)	Added System.IO.Compression.FileSystem.dll .Net assembly reference to the Target
7)	Added System.IO.Compression.ZipFile.dll .Net assembly reference to the Target	
8)	Added PIPESTART event to the "ns_pipeline_master" class.
9)	Added PIPEEND event to the "ns_pipeline_master" class.
10)	Added PIPEMETER event to the "ns_pipeline_master" class.
11)	Added "of_generate_uuid" method to the "nc_business_master" class
12)	Added "of_file_unzip" method to the "nc_business_master" class
13)	Added "of_file_zip" method to the "nc_business_master" class

Release 2018.1.0.68 Service Pack (2018R1) ... June 12, 2018 (GA) PB 17.0.0 Build 1769 (PB2017R2)

1)	Migrated the Web Service framework from PB2017GA to PB2017R2 Universal Edition.
2) 	Changed the release number in nc_ws_master.
3)	Moved ib_debug_mode instance variable to "nc_ws_master" ancestor.
4)	Added HTTP introspection logic to "nc_interface_master".
5)	Added & Revised API declarations as per the Integrated framework (syncronized) in "nc_master".
6)	Revised Web Service release information in "nc_ws_master".
7)	Added SYSTEM.WEB .Net assembly reference to the Target

Release 2017.2.0.65 Service Pack (2017R2) ... July 07, 2017 (GA) PB 17.0.0 Build 1666 (Appeon PB 2017)

1)	Migrated the Web Service framework from PB 12.6 to PB 2017 Universal Edition.
2) 	Changed the release number in nc_ws_master.
3)	Various performance enhancements & alignment to .Net 4.6.
4) 	Added Native PDF support code into the ns_ds_master.  
	(Note: Not yet supported in PB 2017 Web Services in b1119).
5)	Added new MS-Windows API declations into nc_master.
6)	Tested framework on the new W10 "Creator" edition & latest IIS.
7) 	Revised nc_ws_master for default framework version & workspace path.


Release 2017.1.0.59 Service Pack (2017R1) ... May 05, 2017 (GA) PB 12.6.0 Build 4108

1)	Migrated the Web Service framework from PB 12.1 to PB 12.6
2) 	Changed the release number in nc_ws_master.
3)	Various performance enhancements & alignment to .Net 4.5

Release 2016.2.0.57 Service Pack (2016R2) ... June 23, 2016 (GA) PB 12.1.0 Build 6518

1)	Fixed - "Duplicate property name: handle" warning & PB 12.6 migration issue from ns_jagorb_master
2)	Fixed - "Duplicate property name: __ptrdata" warning & PB 12.6 migration issue from ns_mlsync_master
3)	Fixed - "Duplicate property name: anchor" warning & PB 12.6 migration issue from ns_olestorage_master
4)	Fixed - "Duplicate property name: anchor" warning & PB 12.6 migration issue from ns_olestream_master
5)	Fixed - "Duplicate property name: __ptrdata" warning & PB 12.6 migration issue from ns_ulsync_master
6) 	nc_iis_master (of_write_event) - new over-loaded method to use SDK class for MS-Event logging
7) 	nc_iis_master (of_write_event) - Revised original method to call over-loaded method instead
8) 	nc_iis_master - Added & Revised API declarations as per the latest Integrated framework
9) 	ns_ds_webservice_master (RetrieveStart) - Ported newer code over from the Integrated framework
10) 	nc_iis_master (of_get_ini_path) - Changed method's access to public!
11) 	nc_iis_master (of_get_ini_file_name) - Changed method's access to public!
12)	ns_ds_webservice_master (RetrieveStart) - completed code to handle INI file properly.
13)	Revised WebService.INI template INI file to include template entries for the Web Service DataWindow.
14)	Cleaned up various comment blocks & date formats.
15) 	Added example "of_write_event" method call in the OrderEntry example applications Login web service.
16)	Renamed all folders, libraries, objects and variables from "_iis" to "_ws" to better reflect their purpose!
17)	Renamed framework from STD_FC_IIS to STD_FC_WebService!


Release 2016.1.0.55 Major Release (2016R1) ... April 26, 2016 (GA) PB 12.1.0 Build 6518

1)	Removed the "Crypto32.DLL" and "CW3220.DLL" files from the framework!
2) 	Rebuilt the framework's documentation set using VisualExpert 2015 build 2015.0.15.1109
        => Framework documentation now avaialble as a separate ZIP file
3)	Removed external references to the "Crypto32" and "CW3220" DLL's in the nc_crypto_master base class.
4) 	Added new function "of_base64_stringtobinary" to the nc_crypto_master base class.
5) 	Added new function "of_base64_binarytostring" to the nc_crypto_master base class.
6)	Added double quotes around the XOPY file names to handle file path spaces (nc_business_class_master).
7) 	Ported "ns_DS_WebService_Master" class from the Integrated framework for processing within IIs.
8) 	Ported "nc_cipher_master" class from the Integrated framework for processing within IIs.
9) 	Deprecated the "nc_cypher_master" class.
10)	Revised MS-Windows API declarations to match the Integrated Framework.


Release 2015.3.1.53 Emergency Release (2015R3-1) ... October 06, 2016 (GA) PB 12.1.0 Build 6518

1)	Revised MS-Windows API declarations to match the Integrated Framework.


Release 2015.3.1.51 Service Pack (2015R3) ... September 12, 2015 (GA) PB 12.1.0 Build 6518

1)	New INI value "WScript_Shell" (Y/N) that enables/disables WHScript usage.
2)	Revised the "nc_powershell_master" class to handle Windows 10 IIs PowerShell processing properly
3) 	Revised the "nc_powershell_master" class to use WinAPI versus "WScript.Shell".
4) 	Revised the "nc_powershell_master" class to log more information when in DEBUG mode.
5)	Revised the "ns_sqlca_master" class to handle error conditions more effectively.
6)	Revised the "nc_iis_master" class to better set the DEBUG mode based on 
	a combination of the Project object and INI settings.
7)	General code clean-up & optimization.


Release 2015.2.1.45 Service Pack (2015R2) ... May 30, 2015 (GA) PB 12.1.0 Build 6518

1)	Release numbering scheme changed to YYYY(Rn) = Year + Release#
2)	New INI value "Log_Wrap" (Y/N) that enables/disables Log File wrapping
3)	New INI value "Log_Wrap_Size" (NNNNNNNN) - threshold when Log File wrapping is engauged.
4)	New code added to "nc_iis_master" to validate SQLCA, SQLDA, SQLSA, ERROR & MESSAGE classes.
5)	New global function "FN_NVL" added that implememts the "NULL VALUE" DBMS command in PB
6)	New global function "FN_IIN" added that implememts the "IN" DBMS command in PB
7)	New code added to "nc_business_master" to check for valid INI & give diagnostics.


Release 2015.1.0.40 Major Release (2015R1) ... April 30, 2015 (GA) PB 12.1.0 Build 6518

1) 	Renamed class "ns_dda_master" to "ns_sqlda_master" for naming standards.
2) 	Renamed class "ns_dsa_master" to "ns_sqlsa_master" for naming standards.
3) 	Renamed class "ns_transaction_master" to "ns_sqlca_master" for naming standards.
4) 	Renamed class "ns_transaction_ase_master" to "ns_sqlca_ase_master" for naming standards.
5) 	Renamed class "ns_transaction_db2_master" to "ns_sqlca_db2_master" for naming standards.
6) 	Renamed class "ns_transaction_informix_master" to "ns_sqlca_informix_master" for naming standards.
7) 	Renamed class "ns_transaction_oracle_master" to "ns_sqlca_oracle_master" for naming standards.
8) 	Renamed class "ns_transaction_sa_master" to "ns_sqlca_sa_master" for naming standards.
9) 	Renamed class "ns_transaction_sqlite_master" to "ns_sqlca_sqlite_master" for naming standards.
10) 	Renamed class "ns_transaction_ss_master" to "ns_sqlca_ss_master" for naming standards.
11) 	Added a new PBL () to house deprecated objects for each release of the FOundation Classes
    	- Located in the "Deprecated" folder of the Framework.
12)	Revised default application () to use new SQLCA,SQLDA, and SQLSA base ancestor names.
13)	Revised WriteLog's to format the Error Message clearer in "fn_check_db_status".
14)	Created new "fn_xml_ansi_replace" function to replace XML escape code with its ANSI character equivalent.
15)	Created new "fn_xml_symbolic_replace" function to replace ANSI character with its XML escape code equivalent. 
16)	Added new code to load new "logging" information settings from the INI file (nc_business_master)
17)	Added code to remove "<" & ">" from INI and WorkSpace names (nc_iis_master)
18)	Added code to log the Run command if Debug is ON (nc_powershell_master) 
19)	Renamed class "nc_active_directory" to "nc_active_directory_master" for naming standards.


Release 2.3.0.32 Service Pack #3 ... January 29,  2015 (GA) PB 12.1.0 Build 6518
1) 	Added a new Class (ns_ado_rs_master) - (base') Ancestor for all "ADO Result Set" objects.
2) 	Added a new Class (ns_context_information_master) - (Base') Ancestor for all "Context Information" objects.
3) 	Added a new Class (ns_context_keyword_master) - (Base') Ancestor for all "Context Keyword" objects.
4) 	Added a new Class (ns_corbaunion_master) - (base') Ancestor for all "CORBA Union" objects.
5) 	Added a new Class (ns_errorlogging_master) - (Base') Ancestor for all Error Logging objects.
6) 	Added a new Class (ns_exception_master) - (Base') Ancestor for all EXCEPTION handling objects.
7) 	Added a new Class (ns_jagorb_master) - (base') Ancestor for all "Jaguar ORB" objects.
8) 	Added a new Class (ns_mlsync_master) - (base') Ancestor for all "Mobi-Link Syncgronization" objects.
9) 	Added a new Class (ns_olestorage_master) - (base') Ancestor for all "OLE Storage" objects.
10) 	Added a new Class (ns_olestream_master) - (base') Ancestor for all "OLE Stream" objects.
11) 	Added a new Class (ns_olexnobject_master) - (base') Ancestor for all "OLE Extension Object" objects.
12) 	Added a new Class (ns_pipeline_master) - (base') Ancestor for all "PipeLine" objects.
13) 	Added a new Class (ns_profiling_master) - (base') Ancestor for all "Profiling" objects.
14) 	Added a new Class (ns_runtime_error_master) - (Base') Ancestor for all RunTime objects.
15) 	Added a new Class (ns_service_master) - (Base') Ancestor for all "Service" objects.
16) 	Added a new Class (ns_ssl_callback_master) - (base') Ancestor for all "SSL Call Back" objects.
17) 	Added a new Class (ns_ssl_service_provider_master) - (base') Ancestor for all "SSL Service Provider" objects.
18) 	Added a new Class (ns_throwable_master) - (Base') Ancestor for all "Throwable" objects.
19) 	Added a new Class (ns_trace_file_master) - (base') Ancestor for all "Trace File" objects.
20) 	Added a new Class (ns_trace_tree_master) - (base') Ancestor for all "Trace Tree" objects.
21) 	Added a new Class (ns_trans_server_master) - (base') Ancestor for all "Transaction Server" objects.
22) 	Added a new Class (ns_ulsync_master) - (base') Ancestor for all "ULtra-Light Synchronization" objects.
23) 	Revised the example OrderEntry application that calls a PB web service to use a TRY..CATCH 
		between the "Interface" and "Controller" utilizing the new ns_exception_master class.


Release 2.2.2.23 Service Pack #2 ... December 9,  2014 (GA) PB 12.1.0 Build 6518
1) 	Changed WorkSpaceName to WorkSpacePath & modifed logic to be more flexible where the WS source code resides.

Release 2.2.1.22 Service Pack #1 ... December 9,  2014 (GA) PB 12.1.0 Build 6518
1) 	Fixed issue with WorkSpaceName parsing to locate deployed external files.

Release 2.2.0.21 Service Pack #2 ... December 4,  2014 (GA) PB 12.1.0 Build 6518
1) 	Removed the NC_Timer_Master class as the Timer Event is not supported by IIs & .Net.
2)	Added PBDEBUG support for PB 12.6
3)	Added abstract Transaction Object classes for the following DBMS:
           SQLServer, Oracle, DB/2, Informix, & SQLite.
4)	Added new constants: FAIL & SUCCESS to use in methods returning the INI data type. 
5)	Change the Logging sub-system to allow log message redirection via the new "of_set_log_location" method.
6)	Added a new "of_write_database" method to allow logging to a DB versus a file.
7)	Various miscellaneous performance enhancements.
8)	Tested framework with ....
	  - PowerBuilder 12.x, 12.5.x and 12.6
	  - Appeon 2013R2 and Appeon 2015.
	  - MS-Windows 7, 2008 & 2012.
	  - .Net 2.0, .Net 3.5, .Net 4.0 and .Net 4.5
	  - IIs 7.0, 7.5
9)	Added new OLE class to support the open source ImageMagicK product (nc_ole_image_magick).
10)	Added support for multi-session logging.


Release 2.1.0.14 Service Pack #1 ... July 11,  2014 (GA) PB 12.1.0 Build 6518
1) 	Revised PB version checking to be INI driven versus hard coded.
2)	Added new "PB_Version=" parameter to the base INI file.
3)	Added a new "of_copy" method to the base transaction object (ns_transaction_master).
	- allows the copying the current values to a new or existing transaction object.
4)	Fixed an INI file initialization bug when the framework is migrated to a higher PB version.
5)	Added a new "of_is_connected" method to the base transaction object (ns_transaction_master).


Release 2.0.0.01 Initial Release  ... June 05,  2014 (GA)  PB 12.1.0 Build 6518

1)	Ported the base Internet Result Set class "ns_internet_result_master" over from the Integrated framework to the IIs Web Service framework.
2)	Added session INI support to the framework in the BUSINESS abstract ancestor (nc_business_master).
3) 	Added SYSTEM to System control checking (O/S, DB, & PB).
4)	Added resource TRACEing for SQL, print, memory, time, etc to the base ancestor DataStore (ns_ds_master).
5) 	Added support for dynamic language setting to the IIS abstract ancestor (nc_iis_master).
6)	Added processor affinity support.
7)	Added dynamic debug switch support.
8)	Added full error handling to the TRANSACTION object base ancestor (ns_transaction_master).
9)	Added SQL tracing to the TRANSACTION object base ancestor (ns_transaction_master).
10) 	Added "parent" object registration to all STANDARD NON-VISUAL objects via an "of_register" method!
11)	Fixed a formatting bug in the SQL trace of the TRANSACTION and DATASTORE base ancestor objects.
12)	Added default boolean, long and Integer instance work variables to all STANDARD NON-VISUAL objects.
13)	Added new web service CONNECTION object base ancestor (ns_connection_master).
14)	Added INI file support for deployment to session handling
15) 	Added default "WebService.INI" skeleton to the framework as a starter format for your projects.
16)	Added Compile DATE & Time stamps constants to the framework to trap the last "full build" information.


Release 1.1.2.11 Service Pack #2 ... April 24,  2014 (GA) PB 12.1.0 Build 6518

1) 	Ported the function 'fn_check_db_status' over from the Integrated framework to the IIs Web Service framework.
2)      Ported the function 'fn_copy_transaction' over from the Integrated framework to the IIs Web Service framework.
3)      Ported the function 'fn_dbms_get_sysdate' over from the Integrated framework to the IIs Web Service framework.
4)      Ported the function 'fn_iif' over from the Integrated framework to the IIs Web Service framework.
5)      Ported the function 'fn_get_enumerated' over from the Integrated framework to the IIs Web Service framework.
6) 	Added new method 'of_get_virtual_path' to the nc_iis_master class to help locate where your Web service is running inside of IIS.
7) 	Ported the 'sr_pass_data' structure over from the Integrated framework to make them the same.
8)	Added INI file support to the IIS Web Service framework.
9)	Ported the base Message object class "ns_message_master" over from the Integrated framework to the IIs Web Service framework.
10)	Ported the base Error object class "ns_error_master" over from the Integrated framework to the IIs Web Service framework.
11)	Ported the base Dynamic Description Area object class "ns_dda_master" over from the Integrated framework to the IIs Web Service framework.
12)	Ported the base Dynamic Staging Area object class "ns_dsa_master" over from the Integrated framework to the IIs Web Service framework.



Release 1.1.1.07 Service Pack #1 ... January 12, 2014 (GA) PB 12.1.0 Build 6518

1) 	Added the "nc_active_directory" NVUO  object that supports MS-Windows, Novell, etc AD Server communications
2)      New "VE" folder that now contains all the automated framework documentation in web browser format
        - Generated by VisualExpert
3)      New "OOM" Folder that now contains an Object Oriented Model (OOM) of the IIs framework
        - Generated by PowerDesigner
        Note: To view the OOM, use the free PowerDesigner Viewer.
              PD Viewer download link:  https://global.sap.com/campaign/ne/sybase/powerdesigner16_viewer/index.epx?kNtBzmUK9zU


Release 1.1.0.01 Initial Release ... November 4, 2013   (GA) PB 12.1.0 Build 6518

1) 	Many miscellanoeus minor fixes due to "porting" EAS code base
2)	Tweaked various code segments for better IIs performance.



Release 1.0.0.01 Initial Release ... March 5, 2013   (GA) PB 12.1.0 Build 6518

1) 	Ported the EAServer FC's to IIs (February 11, 2013)
2)	Tested with PowerBuilder 12.1.0 (Build 6518 - MR).
3)	Tested with IIsS version 6.0, 7.0 and 7.5.
4)	Added IIs logging
5)	Added PowerShell support
6)	Added MS-Debugger support
7)	Added MS-Windows event logging support
8)	Developed "WS TEST" application to test the IIs based FC's.


======================================== END ============================================