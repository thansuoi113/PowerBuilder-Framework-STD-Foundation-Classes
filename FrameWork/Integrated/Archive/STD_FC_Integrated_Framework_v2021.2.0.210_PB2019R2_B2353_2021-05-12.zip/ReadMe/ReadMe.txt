Software Tool & Die Inc
PowerBuilder "Integrated" Foundation Classes

=================================  HISTORY   ==============================

Release 2021.2.0.210 - May 12, 2021	    - Major Release (2021R2)
Release 2021.1.0.185 - January 14, 2021	    - Major Release (2021R1)
Release 2020.2.0.160 - August 08, 2020	    - Major Release (2020R2)
Release 2020.1.0.148 - April 12, 2020	    - Major Release (2020R1)
Release 2019.4.0.140 - September 01, 2019   - Major Release (2019R4)
Release 2019.3.2.135 - July 31, 2019   	    - Minor Release (2019R3-2)
Release 2019.2.1.132 - June 12, 2019   	    - Minor Release (2019R2-1)
Release 2019.2.0.131 - May 15, 2019    	    - Major Release (2019R2)
Release 2019.1.0.124 - February 06, 2019    - Major Release (2019R1)

Release 2018.5.0.117 - December 18, 2018    - Major Release (2018R5)
Release 2018.4.0.121 - August 14, 2018	    - Major Release (2018R4)
Release 2018.3.0.101 - May 06, 2018	    - Major Release (2018R3)
Release 2018.2.0.97 - March 29, 2018	    - Major Release (2018R2)
Release 2018.1.0.95 - February 11, 2018	    - Major Release (2018R1)

Release 2017.3.0.90 - December 10, 2017	    - Major Release (2017R3)
Release 2017.2.0.76 - July 17, 2017	    - Major Release (2017R2)
Release 2017.1.0.73 - May 17, 2017	    - Major Release (2017R1)

Release 2016.3.0.68 - October 10, 2016      - Service Pack (2016R3)
Release 2016.2.0.65 - June 30, 2016         - Service Pack (2016R2)
Release 2016.1.1.59 - April 26, 2016        - Service Pack (2016R1-1)
Release 2016.1.0.58 - March 23, 2016        - Major Release (2016R1)


** New Version Numbering in effect **
---------  Release Numbering Changed  - YYYY.Rel.Fix.Build ----------------
Release 2015.5.0.50 - December 14, 2015     - Service Pack (2015R5)
Release 2015.4.1.49 - October 27, 2015      - Service Pack (2015R4-2)
Release 2015.4.1.45 - October 06, 2015      - Service Pack (2015R4-1)
Release 2015.4.0.43 - September 29, 2015    - Service Pack (2015R4)
Release 2015.3.0.40 - June 23, 2015   	    - Service Pack (2015R3)
Release 2015.2.0.35 - June 10, 2015    	    - Service Pack (2015R2)
Release 2015.1.0.31 - April 30, 2015        - Major Release (2015R1)

** New Version Numbering in effect (Start of "Integrated" version) **
Release 5.6.0.30	- April 29, 2015 	(Integrated) Service Pack #6
Release 5.5.0.22	- January 21, 2015 	(Integrated) Service Pack #5
Release 5.4.0.21	- December 19, 2014 	(Integrated) Service Pack #4
Release 5.3.0.14	- July  11, 2014 	(Integrated) Service Pack #3
Release 5.2.0.10	- March 31, 2014 	(Integrated) Service Pack #2
Release 5.1.0.05	- January 12, 2014	(Integrated) Service Pack #1
Release 5.0.0.01	- September 16, 2013 	(Integrated) GA

** Old Version Numbering (based on PB Release) **
Release 12.1.0 		- January 17, 2013
Release 12.1.0		- May 22, 2012
Release 12.1.0		- April 10, 2011
Release 11.5.1		- October  09, 2009
Release 11.5.0  	- May 11, 2009
Release 11.2.0		- May 14, 2008
Release 11.1.0		- November 20, 2007
Release 11.0.0 		- July 03, 2007
Release 10.2.1 		- January  05, 2006
Release 9.0.3A 		- November 20, 2005

** Older Version Release notes dropped **


=================================  FORWARD   ==============================

(STD PB FC)

 All Developers;

	Welcome to the the Software Tool & Die (STD) PowerBuilder (PB) development enhancement Foundation Classes (FC). The current framwork generation is a set of "intelligent & Integrated" ancestor objects for PB2017R3 & higher! The FC's have been designed over a long period starting with PowerBuilder 2.0. They are presented here as "freeware" (please see the enclosed STD General license Agreement) and on an "as is" basis. The STD PB FC's are a port of the PocketBuilder compliment originally designed for the PocketPC. The interesting thing about these classes is the "small" footprint and exceptional speed at which it operates. On the PocketPC, where every CPU cycle is precious, the FC's have proven heir worth. Now you can enjoy a "Light" version of the PFC without the heavy learning curve or high compile overhead. The STD PB FC's will compile to aroun 936K (PBD form) compared to nearly 12M for the Sybase PFC's.
 	The STD FC's represent a significant enhancement to the way a PB developer works (productivity), the capabilities of PB / Appeon, and optimization/leverage of the iOS SmartPhone and/or Tablet Operating System. These FC's were developed with the small device footprint in mind, but ... have been made easier to use, more efficient (less overhead), more intuitive, parameter driven and more "Object Oriented"!
	Each release of the STD FC's is geared to it's equivalent PB release! In each PB release there are significant changes. For example to the "Resizing" of dialogs and run time behavior between Build nnnn to Build xxxx,  that we would recommend ONLY using this version of the STD FC's with your PB Build! If you want to use the FC's with a lower Build number, you will experience some weird "real estate" scenarios. These will have to be adjusted for when you migrate to your production build version. But, if do not mind that, it should be a minor realignment effort.
	The STD Fc's come with a "WorkSpace", "Target" and dummy "Application Object". These have been provided to allow you regenerate the objects. It is expected that the PB developer will use this set of BASE and ABSTRACT ancestor objects for their new application development. To keep the FC overhead small, it is expected that the PPB developer will copy and RENAME the FC library to their own project. For example: if you were developing a Help Desk System you might copy the "STD_PB_Base.pbl" and rename it to "HDS_Base.pbl". Then treat the objects in "STD_Base.pbl" as you would the "PFE" layer of the PB PFC. This "STD_Base.pbl" should compile into a ".PKD" file of about 1.2M which compliments the any device with a small foot print!
	I have not had the extensive time to document the STD FC's objects other that in the "oe_Documentation" events and throughout the general code. So please review these areas fully to understand the object(s) behavior. We would recommend also downloading the sample "Order Entry" application built from the STD FC's, as another aid in assimilating the FC learning curve. Both the STD FC's and the "Order Entry" system will be enhanced together to reflect the intended use of the Base / Abstract classes.
	From the GUI point of view, the STD FC's can be used to build either an SDI (Single Document Interface), an MIMD (Multiple interface, Multiple Document) interface, a full MDI interface or now a "Dockable" interface as well. Since the frmaework supports other O/S than MS-Windows, the STD FC's can "emulate" an MDI behavior within the supported O/S's. You will see the ability to use "sheet" like behavior, have an MDI like frame, Menus will track their "Sheet" parents, if you close a Sheet or MDI like frame, their child windows will close automatically, etc.
	Since this FC was developed in Canada's National capital, it was architected to support multiple languages. Of course Canada supports either French or English, but the STD FC's were built to support any combination of languages, either now or in the future. The general approach is "static" language switching (where the user picks the language at "logon" time). In the future, the STD FC's will be "dynamic" language capable as well. But due to the compressed development time frames, this was not coded for version 1.0.
	STD would like to recognize it's Alpha and Beta testers for the STD FC's. This has led to a more polished 1st release of the FC's. It is hoped that as other various parties develop code using the STD FC's or, PB developers have functional requirements not yet supported, they will funnel these back to the author for inclusion in the next release!
	This marks a mile stone for me as an original Beta tester on PB release 0.8 (Nov 1989) to PB2017R3 without missing a Beta cycle. Please enjoy the STD FC's for PB. I hope you find them as fun to use as I had in building them! 

Regards;

Chris Pollach (Author STD FC's)
CEO & President - Software Tool & Die Inc.
aka: Great White North Technical Evangelist (have you hugged your "DataWindow" today?)
e-Mail:	Chris.Pollach@ncf.ca
Blog: http://chrispollach.blogspot.com
PBDJ: http://chrispollach.sys-con.com
SourceForge: http://sourceforge.net/projects/stdfndclass

=================================  CHANGE DETAIL HISTORY   ==============================

Release 2021.2.0.210 Major Release (2021R2) ... May 12, 2021 (GA) PB2019 R2 Build 2353
1) Revised "nc_app_controller_master" - Added SendMessageXxx variant definitions, CreateWindow and InitCommonControlsEx
2) Revised "nc_app_controller_master" - Added instance variables that locate App's toolbar and Microhelp bar in any App
3) Revised "nc_app_controller_master" - Added instance variable for Application NativePDF! switch setting
4) Revised "nc_app_controller_master" - Added code to get Hard Drive "Manufacturer" name & serial number
5) Revised "nc_app_controller_master" - Revised the code to support PB 2019 R3 and higher (No DLL numbering)
6) Revised "nc_app_controller_master" - Removed the use of the iNET object and relaced with Global Function call
7) Revised "nc_app_controller_master" - Added NoWait option argument to the "of_notification_display" method
8) Revised "nc_app_controller_master" - Added new "of_get_toolbar_class" method to Return Class Name of any App's Menu Toolbar
9) Revised "nc_app_controller_master" - Added new of_get_MicoHelp_class" method to Return Class Name of any App's MicoHelp bar class
10) Revised "nc_app_controller_master" - Added NoWait option to the RUN call if required	
11) Revised "nc_app_controller_master" - Added support for NativePDF! via the Application object class (PB2019R2 feature)
12) Revised "nc_pbdebug_pbvm" - Revised the DLL nmes to match the PB 2019R3 run-time (No numbering)
13) Revised "ns_ds_master" - Added switch to enable or disbale XML tracing
14) Revised "vs_dc_master" - Added code to disable spell checking if set OFF in App's INI file
15) Revised "wn_controller_master" - Changed the code to use Class name constant for FNFIXEDBAR & drop ### for >= P2019 R3
16) Revised "wn_master" - Revised the window "ContextHelp" property to be FALSE
17) Created "vs_ole_media_player_master" Object class
18) Revised "vs_ole_media_player_master" - Added "of_play" method
19) Revised "vs_ole_media_player_master" - Added "of_stop" method
20) Revised "vs_ole_media_player_master" - Added "of_pause" method
21) Created "fn_get_class_definition" Global function object class
22) Created "fn_get_enumerated_definition" Global function object class
23) Revised "nc_app_controller_master" - Added "IsWindowUnresponsive" & "PeekMessage" external functions as an SDK call
24) Revised "nc_app_controller_master" - Added "SCardGetStatusChange" external function SDK calldeclaration
25) Revised "nc_app_controller_master" - Changed Structure's "uflags" values to allow more features to be shown	
26) Revised "nc_app_controller_master" - Added code to send a Resize event on a Theme change to allow UO's on toobar to display OK	
27) Revised "wn_controller_master" - Added "ii_window_border_size" and asscoaited methods to track current border size
28) Revised "wn_controller_master" - Revised the ToolBar User Object code to adjust the width by 0 units if a Theme is active!
29) Revised "wn_controller_master" - Added "of_get_window_border_size" method
30) Revised "wn_controller_master" - Added "of_set_window_border_size" method
31) Revised "wn_controller_master" - Added code to track the Window's current border size
32) Revised "wn_controller_master" - Revised the code to observe if a Theme was active!
33) Revised "wn_controller_master" - Added "oe_window_position_changed" Event
34) Created "ns_dotnet_assembly_master" object class Base Ancestor!
35) Created "ns_dotnet_master" object class Base Ancestor!
36) Revised "wn_controller_master" - Added a set "remote-debugging-port" to allow AscentialTest to work with App
37) Revised "nc_app_controller_master" - Revised Class names for PB2019R3. They no longer use version numbers in the name
38) Revised "nc_app_controller_master" - Revised various methods to only have one exit point (VE Audit)
39) Revised "nc_app_controller_master" - Corrected the code for the "PRODUCT_ENTERPRISE_EVALUATION" O/S edition
40) Revised "nc_app_controller_master" - Revised "of_findwindow_partial" method to return the DataStore with partial matches (dw_os_process_list)
41) Revised "nc_app_controller_master" - Added new "of_get_spell_check_required" method and support for the "SpellCheck" INI setting and App functionality
42) Revised "nc_smtp_master" - Converted FileWite to calling Frameworl's logging feature instead
43) Revised "nc_wininet_master" - Revised the code to remove NOT and to set RC code on exit
44) Revised "vs_dc_master" - Added code to allow the App Controller to track if a DDDW is active
45) Revised "vs_dc_master" - Added new "oe_spell_check" method 
46) Revised "vs_dc_master" - Added new "of_get_spellcheck_status" method 
47) Revised "vs_dc_master" - Added code to disable spell checking if set OFF in App's INI file	
48) Revised "vs_em_master" - Added new "oe_spell_check" Event
49) Revised "vs_em_master" - Added new "oe_clear" Event
50) Revised "vs_em_master" - Added new "oe_selectall" Event
51) Revised "vs_em_master" - Added new "of_get_spellcheck_status" Method
52) Revised "vs_em_master" - Added code to disable spell checking if set OFF in App's INI file	
53) Revised "vs_mle_master" - Added new "oe_spell_check" Event
54) Revised "vs_mle_master" - Added new "oe_clear" Event
55) Revised "vs_mle_master" - Added new "oe_selectall" Event
56) Revised "vs_mle_master" - Added new "of_get_spellcheck_status" method
57) Revised "vs_sle_master" - Added new "oe_spell_check" event
58) Revised "vs_sle_master" - Added new "oe_clear" event
59) Revised "vs_sle_master" - Added new "oe_selectall" event
60) Revised "vs_sle_master" - Added new "oe_spell_check" event
61) Revised "vs_sle_master" - Added new "of_get_spellcheck_status" method
62) Revised "wn_controller_master" - Added new "of_get_dc_dddw_active" method
63) Revised "wn_controller_master" - Added new "of_set_dc_dddw_active" method
64) Revised "wn_controller_master" - Revised "oe_window_position_changed" event to Replaced the intial code to support DDDW tracking
65) Revised "vs_rte_master" - Added new "oe_spell_check" event
66) Revised "vs_rte_master" - Added new "oe_clear" event
67) Revised "vs_rte_master" - Added new "oe_selectall" event
68) Revised "vs_rte_master" - Added new "of_get_spellcheck_status" method
69) Revised "vs_rte_master" - Added code to the "rbuttondown" event to support framework pop-up menu


Release 2021.1.0.185 Major Release (2021R1) ... January 14, 2021 (GA) PB2019 R2 Build 2353
1) Revised "vs_dc_list_master" event "RowFocusChanged" to support multi-row selects
2) Revised "vs_dc_list_master" event "clicked" to support multi-band colouring
3) Revised "fn_replace_all" to handle up to 2G of string data vs 32K
4) Created "fn_string_concatenate" to handle *Very Fast* string concatenation
5) Revised "fn_web_browser_control_settings" to log activity (if in DEBUG mode)
6) Revised "nc_app_controller_master" to support Web Browser Control initiualization settings for Constructor event
7) Created "of_check_application_libraries" method in the "nc_app_controller_master" class to check if all the App's PBD / DLL files were deployed with the EXE.
7) Revised "Constructor" event of "nc_app_controller_master" class to perform library checking
8) Revised "ns_sqlca_master" to clear the password in memory after a DB connection (security)
9) Revised "ns_sqlca_master" to add "of_encrypt" method
10) Revised "ns_sqlca_master" to add "of_decrypt" method
11) Revised "vc_master" to add "of_scroll" method to help User Object with O/S scrolling
12) Revised "vs_dc_master" to add "of_scroll" method to help DC control with O/S scrolling
13) Revised "wn_master" to add "of_scroll" method to help Window with O/S scrolling
14) Revised "nc_app_controller_master" function "of_get_rte_control_type" to address PB2019R2's App Object methods that were removed!
15) Revised "ns_sqlca_master" to add boolean SW for secure (encryption) support
16) Revised "ns_sqlca_master" function "of_connect" to log the DB Connection RC & Msg if it fails
17) Revised "wn_controller_master" to add time variables to keep track of overall App usage
18) Revised "wn_controller_master" to log when the application was activated
19) Revised "wn_controller_master" to Log the deactivation of the Application
20) Added   "fn_set_right_left_mode" function to set Application into Right-To-Left mode or turns RTL mode OFF (L2R mode)
21) Revised "mu_master" to add generic string type return code variable (easier progrramming)
22) Revised "nc_app_controller_master" to add "GetProductInfo" external function  declaration
23) Revised "nc_app_controller_master" to add SetProcessDefaultLayout and SetLayout API's for Right-to-Left processing
24) Revised "nc_app_controller_master" to remove EOL MS-Windows logic & comments. 
25) Added   "nc_app_controller_master" method "of_get_product_type" to get MS-Windows product information!
26) Added   "nc_app_controller_master" method "of_set_right_to_left" to  change O/S's "layout flow" (R2L)
27) Revised "nc_app_controller_master" to set Right-To-Left mode based in INI setting
28) Revised "ns_ds_master" to add support for the Storage "Page Size" setting
29) Revised "ns_ds_master" to  set "Memory Storage - Page Size" model for the DWO
30) Revised "ns_ds_master" to add "ib_Dddw_Hsb_Reset" variable to control DDDW HSB Position reset
31) Revised "ns_ds_master" to  reset the "child" DDDW horizontal scrollbar to the far left if required
32) Revised "vs_rte_master" to add "ib_data_modified" variable to track if updates are pending
32) Revised "vs_rte_master" to add "of_is_data_modified" method to support modification tracking
33) Revised "vs_rte_master" method "modified" eventy to support modification tracking
34) Revised "fn_string_concatenate" global function for production ready use and further optimize the code 
35) Revised "fn_web_browser_control_settings" to  to log changes if in DEBUG mode
36) Revised "nc_app_controller_master" to add Subroutine mappings (BlobToUIntArray, StringCharToUInt, & UIntArrayToBlob)
37) Revised "nc_app_controller_master" to log Hard Drive information to the App's log if in DEBUG mode
38) Revised "nc_app_controller_master" to support turning ON/OFF MS-Windows "Ghosting"


Release 2020.2.0.160 Major Release (2020R2) ... August 08, 2020 (GA) PB2019 R2 Build 2353
1) Migrated framework from PB2019 build 2170 to PB2019 R2 build 2353
2) Created new Global Function "fn_is_decimal" - Validates if the number passed in is actually a Decimal
3) Created new Global Function "fn_is_integer" - Validates if the number passed in is actually an Integer
4) Revised "mu_application_master" - Changed icon mappings to use PB2019R2's new icons (where applicable)
5) Revised "nc_app_controller_master" - Added "oe_free_memory_warning" event (Fires when free memory % drops below threshold
6) Revised "nc_app_controller_master" - "of_set_theme" method to log ApplyTheme RC
7) Revised "wn_master" to comply with PB2019 R2 Theme activation
8) Revised "wn_profile_master" to Added visual indicator for when this feature ON or OFF
9) Revised "wn_zoom_master" to fix improper focusing on DC while Zooming!
10) Revised "nc_app_controller_master" - Added "sr_memory_counters" structure for the "GetProcessMemoryInfo" API
11) Revised "nc_app_controller_master" - Updated the "GetModuleFileName" API declaration
12) Revised "nc_app_controller_master" - Added GetProcessMemoiry Info API and associated structure
13) Revised "wn_debug_list_master" - Added code to check memory & log it after a Garbage Collection request
14) Revised "wn_debug_list_master" - Added MSG to Log for tracability
15) Created "vs_ribbon_master" class as an  Ancestor for all Ribbon Bar Objects.
16) Created "vs_web_browser_master" class as an  Ancestor for all Web Browser Objects.
17) Created "vs_ole_media_master" class as an Ancestor for all Windows Media Player OCX based objects
18) Revised "vs_htb_master" class to add "oe_sbnthumbposition" event to Map the mouse wheel
19) Revised "vs_vtb_master" class to add "oe_sbnthumbposition" event to Map the mouse wheel
20) Revised "wn_controller_master" class to ensure Controller Window was still instantiated before close All
21) Revised "wn_profile_master" class to Add visual indicator for when this feature ON or OFF
22) Created "vc_tp_about_process" tab page class to display Process and GUI resources used
23) Revised "wn_debug_list_master" class to Add new CB_Model, pb_dump, pb_garbage and pb_break buttons
22) Created "wn_profile_model_master_e" window class to display Process Model information



Release 2020.1.0.148 Major Release (2020R1) ... April 12, 2020 (GA) PB2019 Build 2179
1) Migrated framework from PB2019 build 2082 to PB2019 build 2170
2) Revised "of_set_powerserver_environment_info" method in "nc_app_controller_master" object class to set bitness on mobile devices & fix 64bit detection on Web Apps
3) Revised "of_write_event" method in "nc_app_controller_master" object class to remove code when in 64 bit WEB mode due to PS2019 bug (Ticket#3351)
4) Revised "Constructor" method in "nc_app_controller_master" object class to check INI file for RTE Check Type indicator before actually checking
5) Revised "of_commit" method in "ns_sqlca_master" object class to log the COMMIT command when in debug mode
6) Revised "of_disconnect" method in "ns_sqlca_master" object class to  log the Disconnect command if SQL Tracing is ON!
7) Revised "of_connect" method in "ns_sqlca_master" object class to log the Connect command if SQL tracing is ON
8) Revised "of_connect" method in "ns_sqlca_master" object class to get messages from message service vs hard coded
9) Revised "oe_tab_out" method in "vs_dc_master" object class to Added special DW mapping for futher use
10) Revised "oe_tabup_out" method in "vs_dc_master" object class to Added special DW mapping for futher use
11) Revised "oe_tabdown_out" method in "vs_dc_master" object class to Added special DW mapping for futher use
12) Revised "oe_escape" method in "vs_dc_master" object class to Added special DW mapping for futher use
13) Revised "scrollhorizontal" method in "vs_dc_master" object class to handle whether Pane#1 scrolls when DW in Split mode
14) Revised "fn_build_number" object class to Updated code to use current App's INI file
15) Revised "selected" method in "mu_application_master" object class to removed old WPF code
16) Revised "Constructor" method in "nc_app_controller_master" object class to check the O/S privileges and also log the status (enabled = Y/N)
17) Added   "oe_android_back_button" method in "nc_app_controller_master" object class to Receives control from the framework when the Andoid device's BackButton is pressed.
18) Revised "of_check_exe_version" method in "nc_app_controller_master" object class to Remove old #IF WebService code as these features are deprecated
19) Revised "of_set_cpu_affinity" method in "nc_app_controller_master" object class to Remove old WPF and Winform code as these features are deprecated
20) Added   "of_is_audit_trail" method in "nc_app_controller_master" object class to be called by the framework or PB App
21) Revised "of_set_cpu_affinity" method in "nc_app_controller_master" object class to Remove old WPF and Winform code as these features are deprecated
22) Revised "Constructor" method in "nc_app_controller_master" object class to check for the presence of an INI in a PowerServer App as well.	
23) Revised "oe_post_constructor" method in "nc_app_controller_master" object class to Remove old WPF code line
24) Revised "of_browseforfolder" method in "nc_powershell_master" object class to check for the presence of an INI in a PowerServer App as well.
25) Created new "nc_powershell_master" object class to interface with O/S "PowerShell" feature	
26) Added   "of_browseforfolder" method in "nc_powershell_master" object class to Introspects the O/S privileges
27) Revised "ns_ds_master" object class to Added statistical counters for DML activity tracking
28) Added   "of_is_external_source" method in "ns_ds_master" object class to Checks the current DWO if its an "External" type
29) Revised "sqlpreview" method in "ns_ds_master" object class to Added SQL Function & Type tracking / logging feature
30) Revised "retrievestart" method in "ns_ds_master" object class to Added code to check for invalid DWO versions and external DWOs being retrieved!
31) Added   "of_is_external_source" method in "vs_dc_master" object class to  Checks the current DWO if its an "External" type
32) Revised "retrievestart" method in "vs_dc_master" object class to check for invalid DWO versions and external DWOs being retrieved!
33) Revised "sqlpreview" method in "ns_ds_master" object class to Added SQL Function & Type tracking / logging feature
34) Revised "sqlpreview" method in "wn_controller_master" object class to Added SQL Function & Type tracking / logging feature
35) Revised "ns_ds_master" object class to Activate the Horizontal Scroll and Vertical Scroll properties by default to ON
36) Revised "resize" method in "wn_logon_master" object class to Remove old WinForm code
37) Revised "of_set_cpu_affinity" method in "nc_app_controller_master" object class to handle up to 64 CPU's (ie: 32+) on large servers	
38) Revised "of_set_cpu_affinity" method in "nc_app_controller_master" object class to Changed the code to restrict Affinity setting if > 64 CPU's 
39) Revised "of_set_cpu_affinity" method in "nc_app_controller_master" object class to Refactored the code to allow PowerServer Web Apps to assign a CPU
40) Revised "of_is_user_administrator" method in "nc_app_controller_master" object class to Refactored the code to allow PowerServer Web Apps to assign a CPU
41) Added   "of_is_runas_administrator" method in "nc_app_controller_master" object class to Returns whether the current application 
		has been started by "Run As Admin" command
42) Revised "of_register_nvuo" method in "nc_app_controller_master" object class to Tracks NVUO's of all types and assigns a tracking number
43) Revised "of_is_runas_administrator" method in "nc_powershell_master" object class to Check if the user running the App is an Admin
44) Revised "of_register_nvuo" method in "nc_app_controller_master" object class to Tracks NVUO's of all types and assigns a tracking number
45) Revised "Destructor" method in "nc_app_controller_master" object class to enhance the SQL tracing to the App's log.
46) Revised "wn_response_master" object class to Tracks NVUO's of all types and assigns a tracking number
47) Added   "ib_move_outside_app" variable in "wn_response_master" object class to control Response's movement behaviour outside of the App
48) Revised "oe_postconstructor" event in "wn_contact_pipeline_e" object class to  Fix the "Owner" pointer.
49) Revised "oe_postconstructor" event in "mu_master" object class to clean-up the DataStore when the Menu is about to be destroyed
50) Revised "of_set_theme" method in "nc_app_controller_master" object class to use a relative path if App is running as an EXE
51) Added   "of_get_all_registered_nvuos" method in "nc_app_controller_master" object class to Returns all the NVUO pointers that have been registered!/
52) Revised "of_register_nvuo" method in "nc_app_controller_master" object class to add a PB generated tracking Number (PBVM does not support NVUO "Handle").
53) Revised "nc_pbdebug_pbvm190"object class to Revised DLL name to match PB2019 run-time name
54) Revised "of_get_tracker_no" method in "ns_ds_master" object class to  Get Framework's assigned "tracking #" for the NVUO in question
55) Revised "oe_postconstructor" method in "ns_sqlca_master" object class to register this class with the App Controller for tracking!	
56) Added   "oe_dw_mousemove" method in "vs_dc_master" object class to allow DW Object's mouse move notification
57) Revised "oe_close_all" method in "nc_app_controller_master" object class to stop All drawing when multiple closes are happening
58) Revised "SelectionChanged" method in "wn_debug_list_master" object class to Added a new tab page for NVUO processing
59) Revised "Open" method in "wn_main_master" object class to always check for a valid Window pointer
60) Added   "oe_syscommand" method in "wn_response_master" object class to trap the Left mouse click on the Window title bar 
61) Revised "of_check_ps_version" method in "nc_app_controller_master" object class to emove the use of the "of_getappeonadtversion" method. 
             Deprecated in PS2019 (Build 2170)
62) Added  "of_get_sqlstate" method in "ns_ds_master" object class to  get the SQLState value from the SQL Error Text data
63) Revised "dbError" method in "ns_ds_master" object class to capture the DBMS's SQLState if using ODBC client	 AND
		log more information about the DBMS error 
64) Added  "of_get_sqlstate" method in "ns_sqlca_master" object class to get the SQLState value from the SQL Error Text data
65) Revised "dbError" method in "ns_sqlca_master" object class to capture the last SQLState values returned; 
    		capture the DBMS's SQLState if using ODBC client AND Get, Save and Log the SQL State value(s)
66) Added   "oe_paste" method in "vc_em_hinttext_master" object class to Show or Hide "hittext" as required
67) Added   "oe_copy" method in "vc_em_hinttext_master" object class to Show or Hide "hittext" as required
68) Added   "oe_cut" method in "vc_em_hinttext_master" object class to Show or Hide "hittext" as required
69) Revised "oe_paste" method in "nc_app_controller_master" object class to Show or Hide "hittext" as required
70) Added  "of_get_sqlstate" method in "ns_dc_master" object class to get the SQLState value from the SQL Error Text data
71) Revised "dbError" method in "ns_dc_master" object class to capture the DBMS's SQLState if using ODBC client	 AND
		log more information about the DBMS error 
72) Added   "oe_paste" method in "vs_em_master" object class to Perform a "paste" to O/S Clipboard interaction.
73) Added   "oe_copy" method in "vs_em_master" object class to Perform a "copy" to O/S Clipboard interaction.
74) Added   "oe_cut" method in "vs_em_master" object class to Perform a "cut" to O/S Clipboard interaction.
75) Added   "oe_copy" method in "vs_mle_master" object class to Perform a "copy" to O/S Clipboard interaction.
76) Added   "oe_cut" method in "vs_mle_master" object class to Perform a "cut" to O/S Clipboard interaction.
77) Added   "oe_copy" method in "vs_sle_master" object class to Perform a "copy" to O/S Clipboard interaction.
78) Added   "oe_cut" method in "vs_sle_master" object class to Perform a "cut" to O/S Clipboard interaction.
79) Added   "oe_copy" method in "vs_rte_master" object class to Perform a "copy" to O/S Clipboard interaction.
80) Added   "oe_cut" method in "vs_rte_master" object class to Perform a "cut" to O/S Clipboard interaction.
81) Revised "of_generate_dw_json" method in "ns_json_generator_master" object class to Correct the DS destroy process
82) Revised "of_get_groups" method in "nc_active_directory_master" object class to  register the parent of "ns_oleobject_master"
83) Revised "of_get_machine_name" method in "nc_active_directory_master" object class to  register the parent of "ns_oleobject_master"
84) Revised "of_get_group_membership" method in "nc_active_directory_master" object class to  register the parent of "ns_oleobject_master"
85) Revised "of_is_login_valid" method in "nc_active_directory_master" object class to  register the parent of "ns_oleobject_master"
86) Revised "Constructor" method in "nc_active_directory_master" object class to  register the parent of "ns_oleobject_master"
87) Revised "Close" method in "nc_app_controller_master" object class to  call "of_log_nvuo_usage" function that lists NVUO's still open at close;
		clean-up DS/DWO used for memory statistics AND save Memory/Device/Paging statistics if tracking is ON for analysis
88) Added   "oe_application_memory_changed" method in "nc_app_controller_master" object class to Monitor / acivated when DW Object's memory has changed.
89) Revised "of_set_powerbuilder_environment_info" method in "nc_app_controller_master" object class to get the "Process ID" from local O/S
90) Added   "of_log_nvuo_usage" method in "nc_app_controller_master" object class to Log NVUO use at EOJ
91) Added   "of_get_process_id" method in "nc_app_controller_master" object class to Return O/S process ID captured at App start-up by the framework
92) Added   "of_check_available_memory" method in "nc_app_controller_master" object class to calculate how much resources the App is consuming.
93) Revised "oe_post_constructor" method in "nc_master" object class to register the NVUO to the App Controller's NVUO tracker
94) Revised "Constructor" method in "nc_powershell_master object class to register the parent of "ns_oleobject_master".
95) Revised "oe_postconstructor" method in "ns_ds_master" object class to register the NVUO to the App Controller's NVUO tracker
97) Added   "oe_postconstructor" method in "ns_internet_master" object class to (Missing)
98) Revised "oe_postconstructor" method in "vc_tp_about_device" object class to include better "Load" statistics
99) Revised "Open" method in "nc_app_controller_master" object class to Remove Registraton logic as Ancestor will now perform this processing
100) Revised "oe_postconstructor" method in "wn_debug_list_master" object class to Remove check for MAIN window and let any Window class resolve it!
101) Added   "of_get_window_open_type" method in "wn_master" object class to Return the "worded" window type
102) Revised "Open" method in "wn_master" object class to  allow every window type to be tracked!
103) Revised "pageleft" method in "wn_zoom_master" object class to Remove position computation as control does that automatically now
104) Revised "pageright" method in "wn_zoom_master" object class to Remove position computation as control does that automatically now
105) Revised "lineleft" method in "wn_zoom_master" object class to Remove position computation as control does that automatically now
106) Revised "lineright" method in "wn_zoom_master" object class to Remove position computation as control does that automatically now
107) Revised "fn_print_window" object class to handle the print if the "controller" window is not present
108) Added   "of_register_nvuo" method in "nc_app_controller_master" object class to Monitor/acivate when DW Object's memory has changed.
109) Revised "oe_close" method in "nc_app_controller_master" object class to  clean-up DS/DWO used for memory statistics AND
		save Memory/Device/Paging statistics if tracking is ON for analysis
110) Revised "of_check_available_memory" method in "nc_app_controller_master" object class to update mobile instance variables for viewing in debugger
		AND clear statistics DataStore if Memory Warp is ON
111) Revised "of_check_available_memory" method in "nc_app_controller_master" object class to pass multiple data points via the common framework's structure
		AND  update mobile instance variables for viewing in debugger	AND clear statistics DataStore if Memory Warp is ON
112) Added   "of_write_console" method in "nc_app_controller_master" object class to allow messages to be written to the MS-Windows "Console"!
113) Revised "Constructor" method in "nc_app_controller_master" object class to set Memory tracking / warning SW's and Threshold %'s
114) Revised "oe_postconstructor" method in "vc_tp_about_processor" object class to 
115) Revised "oe_postconstructor" method in "wn_debug_list_master" object class to  Check if running within the PB IDE
116) Revised "wn_debug_list_master" object class to Invoke the PB IDE's"Debugger"
117) Revised "of_get_window_open_type" method in "wn_main_master" object class to use a function to get the Sheet type if not a special docable one	
118) Revised "oe_set_theme" method in "wn_master" object class to WortkAround for PB2019 R2 Theme issue when activating a new Theme
119) Revised "Resize" method in "wn_master" object class to Check If in DEBUG mode and if so, write state to App log!
120) Revised "oe_PostConstructor" method in "vc_tp_about_mobile" object class to get Device's platform name
121) Added   "oe_free_memory_warning" method in "nc_app_controller_master" object class to monitor critical application available memory 
		 when the memory % free drops below the threshold (as set in INI file)


Release 2019.4.0.140 Major Release (2019R4) ... September 01, 2019 (GA) PB2019 Build 2082
1) Migrated framework from PB2017R3 build 1880 to PB2019 build 2082
2) Revised "mu_application_master" base class to add the following Theme support: 
	(Dark, Blue, Grey, Silver & "None")
3) Revised "of_send_mail" method in "nc_app_controller_master" object class to remove PS Mobile compile Error/Warning.
4) Revised "of_set_network_info" method in "nc_app_controller_master" object class to remove IE workaround code for PS2017.
	Issue now fixed in PS2019 by Appeon.
5) Revised "of_set_powerserver_environment_info" method in "nc_app_controller_master" object class to test the network performance & log it for debug tracing
6) Revised "of_set_powerserver_environment_info" method in "nc_app_controller_master" object class to remove "of_getappeonadtversion" method call as it is now deprecated in PS2019.
7) Added "of_set_theme" method in "nc_app_controller_master" object class to support PB2019 "Theme" feature.
8) Added "of_get_theme" method in "nc_app_controller_master" object class to support PB2019 "Theme" feature.
9) Revised "oe_mouse_move" event in "vs_dc_list_master" object class to support DWO row highlighting as mouse moves over data.
10) Added "of_set_tandem_scrolling" method in "vs_dc_master" object class to support DC to DC synchronized Vertical, Horizontal & Split scrolling.
11) Revised "ScrollVertical" event in "vs_dc_master" object class to support synchronized scrolling.
12) Revised "ScrollHorizontal" event in "vs_dc_master" object class to support synchronized scrolling.
13) Added "oe_toolbar_text" event in "wn_master" object class to control the display of "Toolbar Text".
14) Revised the "ToolbarMoved" event in "wn_master" object class to control the display of "Toolbar Text".
15) Revised the "Other" event in "wn_master" object class to control the display of "Toolbar Text".
16) Added new object base class "ns_compressor_master" to support new PB2019 compression feature
17) Added new object base class "ns_extractor_master" to support new PB2019 decompression feature
18) Added new object base class "ns_json_packager_master" to support new PB2019 JSON Packaging feature
19) Added new object base class "ns_json_parsor_master" to support new PB2019 JSON Parsing feature
20) Revised the Framework Release & Date in "nc_app_controller_master" base object class.
21) Revised the "of_connect" event in "ns_sqlca_master" object class to get messages from message service vs hard coded.
22) Added new PBL (STD_FC_BaseW) library to contain object classes "shared" between PB & PS.


Release 2019.3.2.135 Mminor Release (2019R2) ... July 31, 2019 (GA) PB2017R3 Build 1880
1) Added KeyBoard layout API definitions.
2) Revised "of_findwindow" method in "nc_app_controller_master" object class to use an extyended search if basic search fails.
3) Added new "of_get_powerserver_session" method in "nc_app_controller_master" object class
4) Added new public "of_findwindow_partial" method in "nc_app_controller_master" object class
5) Added new "oe_os_setting_changed" method in "nc_app_controller_master" object class
6) Removed "nc_pbdebug_pbvm180" object class as PB2018 was never released
7) Added TimeZone API definitions in "nc_app_controller_master" object class
8) Revised the release number to "2019.3.2.135" in "nc_app_controller_master" object class 
9) Revised "of_is_application_instantiated" method in "nc_app_controller_master" object class to check for Web Browser duplicate App's
10) Created new "nc_app_controller_master" object class support UTC time to Local time
11) Added new "of_utc_to_local_datetime" method in "nc_app_controller_master" object class to utilize NVUO Helper to  get UTC=<Local Time


Release 2019.2.1.132 Minor Release (2019R2) ... June 12, 2019 (GA) PB2017R3 Build 1880
1) Added new function "of_get_number_monitors" to the "nc_app_controller_master" object base class.
2) Added new function "of_get_current_monitor" to the "nc_app_controller_master" object base class.
3) Added new function "of_is_tablet_pc" to the "nc_app_controller_master" object base class.
4) Revised "constructor" event of "nc_app_controller_master" base class to Check # monitors and if running on a Tablet PC
5) Revised "oe_postopen" event of "wn_controller_master" base class to record the monitor position of the App at start-up
6) Revised "oe_postopen" event of "wn_main_master" base class to help with Window focus on OpenSheet() command in PowerServer apps
7) Added new menu item in "mu_application_master" base class to support PB2019 release's new "DARK" theme.
8) Revised "of_run" function of "nc_app_controller_master" base class to capture the current working directory and then restore it after running external Application


Release 2019.2.0.131 Major Release (2019R2) ... May 15, 2019 (GA) PB2017R3 Build 1880
1)  Added "Process" API external declarations into "nc_app_controller_master" base class
2)  Added "of_get_rte_control_type" function into "nc_app_controller_master" base class to get RTE 3rd party control being used
3)  Revised "Constructor" event of "nc_app_controller_master" base class to validate RTE 3rd party control
4)  Added Boolean SW to "nc_app_controller_master" base class to support PB2019 "Themes" feature ON/OFF
5)  Revised "nc_app_controller_master" base class to log the application's Library List at start-up
6)  Revised "nc_app_controller_master" base class to handle Dockable App Restore on App Restart	
7)  Revised "nc_app_controller_master" base class to make the O/S Path more "readable" in the App Log
8)  Revised "nc_app_controller_master" base class to make sure that only PB App's use App Object's dynamic methods
9)  Added new "of_is_theme_feature_active" method to "nc_app_controller_master" base class for PB2019 support
10) Added new "of_set_themes_active" method to "nc_app_controller_master" base class for PB2019 support
11) Added new "of_call_phone_number" method to "nc_app_controller_master" base class
12) Added new "of_set_dockable_restore" method to "nc_app_controller_master" base class for more Dockable Window support
13) Added new "of_get_dockable_restore" method to "nc_app_controller_master" base class for more Dockable Window support
14) Revised "nc_app_controller_master" base class's "of_notification_display" method to use MS-Windows "PBNotify" App to send W10 message
15) Revised "nc_app_controller_master" base class's "Contructor" event to check if a Dockble app Restore is required
16) Revised "nc_app_controller_master" base class's "Contructor" event to add MS-Windows notify EXE commandline setting	
17) Revised "ns_ds_master" base class's "WSError" event to log Web Service "Buffer" name to the log
18) Revised "ns_ds_master" base class's "RetrieveStart" event to allow DWO to try and keep band data together as much as possible
19) Revised "nc_app_controller_master" base class's "oe_postopen" event to handle Dockable Restore mode
20) Revised "nc_app_controller_master" base class's "CloseQuery" event to save Dockable stateof all open Document Sheets
21) Revised "wn_master" base class's "oe_set_theme" event to check if themes are active and set mouse pointer accordingly
22) Revised "nc_app_controller_master" base class's "of_set_network_info" method to bypass network adapter check if browser = IE - PS2017 (bug)
23) Revised "nc_app_controller_master" base class's "of_check_aws_version" method to retrieve AWS's AppName and AppURL
24) Added new "of_get_powerserver_version" method to "nc_app_controller_master" base class to get PS version (release)
25) Revised "nc_app_controller_master" base class's "Constructor" method to grab NetWork Adapter information from PS Web Apps
26) Revised "nc_powershell_master" base class's "of_run" method to  log the PowerShell command's Return Code
27) Revised "wn_master" base class's "oe_drop_files" event to logging when "debug" switch is ON	
28) Revised "wn_messagebox_master" base class's "oe_postopen" event to allow no CommandButton default if a Zero is passed
29) Revised "fn_print_screen" global function base class to use external printscreen when in PowerServer mode
30) Revised "fn_print_screen" global function base class to adjust for PB Units to Pixels for proper sizing
31) Revised "fn_print_window" global function base class to handle PS Web App's where Object.Print() is not supported
32) Revised "nc_app_controller_master" base class's "Instance Variables" to support the location of the PrintScreen application
33) Revised "nc_app_controller_master" base class's "Instance Variables" to support the location of the PrintWindow application
34) Revised "wn_main_master" base class's "oe_postopen" event to help with Window focus on OpenSheet() command in PowerServer apps
35) Revised "wn_master" base class's "deactivate" event to  "top most" (forground) window position if "ib_always_on_top" SW is ON



Release 2019.1.0.124 Major Release (2019R1) ... February 06, 2019 (GA) PB2017R3 Build 1858
1)  Revised "mu_application_master" object class to add support for "Themes" in PB 2018 or higher	
2)  Revised "nc_app_controller_master" object class to 
	a)  Track Theme in use
	b)  Allow sending a Return Code back to the calling App or O/S
	c)  Added HEAP memory command declarations
	d)  Perfrom Controller Close before a Restart
	e)  Get the PS App's "run mode" & log it for debug tracing
	f)  Retrieve PowerServer session count information
3)  Added "nc_pbdebug_pbvm180" object class to add support for debug tracing in PB 2018
4)  Added "nc_pbdebug_pbvm190" object class to add support for debug tracing in PB 2019
5)  Revised "nc_systemtray_master" object class to use external functons now located in the "nc_app_controller_master" object class
6)  Revised "ns_sqlca_master" object class to issue either a Commit or Rollback on disconnect
7)  Revised "wn_controller_master" object class to issue either a Commit or Rollback on disconnect
	a)  Added Yield command to allow proper resource clean-up between Window closes
	b)  Revised code to automatically compute FNFIXEDBAR version	
	c)  Added code to save the location & size of this window to the INI file
	d)  Added code to restore the window to its last known position & size
	e)  Added code to close All Windows before the Controller window	
8)  Revised "wn_master" object class to restore last App "Theme" used when App shutdown previously
9)  Revised "wn_popup_master" object class to center window on last controller's position
10) Revised "wn_response_master" object class to center window on last controller's position
11) Added new "vs_ole_browser_master" object class to allow an embedded IE Web Browser.


Release 2018.5.0.117 Major Release (2018R5) ... December 18, 2018 (GA) PB2017R3 Build 1858
1)  Added Environment object to "nc_app_controller_master" class to double check APP's bitness in DEBUG mode
2)  Revised "nc_app_controller_master" object class to always write bitness to the App's Log
3)  Revised "nc_app_controller_master" object class to write RTE Control type to the App's log
4)  Added a 64bit Structure for the support of 64bit App's in "nc_app_controller_master" object class
5)  Added a 64bit Structure for the support of 64bit App's in "nc_app_controller_master" object class
6)  Added the following external functions to the "nc_app_controller_master" object class ...
    SetParent, SetForegroundWindow, GetForegroundWindow, Printer methods, WriteProfileXxxxx methods, LoadImage and Extraction
7)  Added code to GetFocus/LooseFocus events of "vs_cb_master" oject class to hanlde "Flat" button style.
8)  Added ib_auto_hscroll variable to "vs_dc_detail_master" object class to control automatic horizontal scrolling on column focus 
9)  Added ib_auto_vscroll variable to "vs_dc_detail_master" object class to control automatic vertical scrolling on column focus
10) Added is_save_3d_mode variable to "vs_dc_detail_master" object class to restore 3D mode state
11) Added code to "vs_dc_detail_master" object class "ItemFocusChanged" event to handle #8,9,10 new features
12) Added method "of_add_control_to_toolbar" to "wn_controller_master" object class to allow adding a User Object to the current Menu's Toolbar at run-time
13) Revised "wn_controller_master" object class "oe_postopen" event script to allow a User Object on the current menu toolbar
14) Revised "fn_open_sheet_as_document" object class to renaming "ae2_tab_alignment" argument to "ab_tab_alignment" for naming consitency
15) Added "Printer" status constants variable declarations to "nc_app_controller_master" object class 
16) Added method "of_set_app_ini_name" to "wn_controller_master" object class to allow any App to dynamically change the INI name at run-time
17) Revised "ns_ds_master" object class to optimize code to prevent addressing a NULL buffer in the "oe_buffer_trace" event
18) Revised "vs_dc_master" object class to optimize code to prevent addressing a NULL buffer in the "oe_buffer_trace" event
19) Revised "nc_app_controller_master" object class to add "RTE" control variable that identifies which 3rd party control is being used
20) Revised "nc_app_controller_master" object class "of_set_powerbuilder_environment_info" method to write RTE Control type to the App's log
21) Revised "nc_app_controller_master" object class to add "of_get_rte_control_type" method to retieve the RTE Control type being used by the current App
22) Revised "nc_app_controller_master" object class "Constructor" event to add INI check for RTE Control type being used
23) Revised "vs_dc_master" object class "oe_dddw_drop" event on child DDDW to have the same band colours as the DW List DWO's in the App.
24) Revised "vs_dc_master" object class "oe_dddw_drop" event on child DDDW to DDDW the same Zoom % as its parent DWO
25) Revised "wn_main_master" object class property to have a MAX box enabled
26) Revised "nc_app_controller_master" object class "of_set_powerserver_environment_info" method to handle new AWS App run-time settings from INI file values
27) Revised "nc_app_controller_master" object class "Constructor" event to removed old Colour "Default" logic and now handle these from associated Get functions
28) Revised "nc_app_controller_master" object class "Constructor" event to  track how many times App was used (Usage_Counter) in INI file
29) Revised "vs_dc_master" object class "oe_dddw_drop" event on child DDDW to control Even/Odd row highlighting
30) Revised "vs_dc_master" object class adding new "oe_left_mouse_click" event to handle DDDW Open/Close processing state
    Note1: Also a workaround for the "oe_dddw_close" event not being fired by the PB & PS run-times (PB/PS bug)
    Note2: Also revised the "itemfocuschanged" event code for the same issues as above
31) Added new "vs_ole_browser_master" object class to allow proper embedding of the "IE Web Browser" in PB native Apps.
32) Revised "nc_systemtray_master" object class to replace ANSI based MS-Window API's with their Unicode equivalent (where applicable)
 

Release 2018.4.0.121 Major Release (2018R4) ... August 14, 2018 (GA) PB2017R3 Build 1858
1)  Added TimeZone API defintions to  the "nc_app_controller_master" class
2)  Added MessageXxxxxx API defintions to  the "nc_app_controller_master" class
3)  Added new "oe_dropdown" event to the "vs_ddlb_master" object class to signal a "drop"
4)  Added new "oe_closeup" event to the "vs_ddlb_master" object class to signal a "collapse"
5)  Added new "oe_dropdown" event to the "vs_ddplb_master" object class to signal a "drop"
6)  Added new "oe_closeup" event to the "vs_ddplb_master" object class to signal a "collapse"
7)  Added MessageBeep API support to the "wn_messagebox_master" object class
8)  Added code to the "PipeStart" event of the "ns_pipeline_master" object class
9)  Added code to the "PipeEnd" event of the "ns_pipeline_master" object class
10) Added code to the "PipeMeter" event of the "ns_pipeline_master" object class
11) Added new "of_generate_uuid" method code to  the "nc_app_controller_master" class
12) Created new "ns_coder_master" object class to support Encoding/Decoding
13) Created new "ns_crypter_master" object class to support Encryption/Decryption
14) Created new "ns_listview_item_master" object class
15) Created new "ns_oauth_client_master" object class to support oAuth 2.0 security
16) Created new "ns_oauth_request_master" object class to support oAuth 2.0 security
17) Created new "ns_restful_client_master" object class to support RESTful web services
18) Created new "ns_token_request_master" object class to support oAuth 2.0 security
19) Created new "ns_token_resonse_master" object class to support oAuth 2.0 security
20) Created new "ns_treeview_item_master" object class to support TreeView Control
21) Revised "oe_postconstructor" event of "mu_application_master" to support MDI Dockable windows
22) Revised "oe_predestructor" event of "mu_application_master" to correct NULL Object error
23) Added SystenFunctions reference to the "nc_app_controller_master" class for ease of coding
24) Revised "of_set_pb_environment" method of "mu_application_master" to check proper bitness
25) Created new "vc_em_hinttext_master" object class to Edit Mask object with "hint text"
26) Created new "vc_mle_hinttext_master" object class to Multi-Line object with "hint text"
27) Created new "vc_sle_hinttext_master" object class to Single Line object with "hint text"
28) Created new "ns_enumeration_definition_master" object class to support ENUM operations
29) Revised all the icons in the "mu_application_master" object class to have a more modern look
30) Migration of entire framework from PB2017R2 Build 1769 to PB2017R3 Build 1858
31) Revised the "ns_restful_client_master" object class to accomdate R3 method signature changes


Release 2018.3.0.101 Major Release (2018R3) ... May 06, 2018 (GA) PB2017R2 Build 1769
1)  Added  PRINTER functions and GetTickCount [32/64] & LocalFree API defintions in "nc_app_controller_master"
2)  Corrected platform code for Web or IWA based Applications in "nc_app_controller_master"
3)  Renamed "of_set_appeon_environment_info" to "of_set_powerserver_environment_info" in "nc_app_controller_master"
4)  Added code to zoom the DDDW to the same % as the parent DWO	in "vs_dc_master"
5)  Notification message only displayed if not in "silent" mode in "wn_controller_master"
6)  Added code to change the background colour if in a Web/ Mobile env in "wn_master"
7)  Added code to check if graphic object pointer is valid in "wn_master"
8)  Renamed "STD_FC_Appeon.pbl" library to "STD_FC_PowerServer.pbl"
9)  Added new global function "fn_add_numbers_in_string"
10) Added new global function "fn_compute_elapsed_date_period"
11) Added new global function "fn_compute_elapsed_minutes"
12) Added new global function "fn_compute_week_no"
13) Added new global function "fn_get_string_segment"
14) Added new global function "fn_get_windows_registry_no"
15) Added new global function "fn_get_windows_registry_string"
16) Added new global function "fn_ltrimx"
17) Added new global function "fn_object_last_modified"
18) Added new global function "fn_positive_match"
19) Added new global function "fn_remove_character_from_string"
21) Added new global function "fn_replace_character_in_string"
22) Added new global function "fn_remove_character_from_string"
23) Removed old WPF code in "mu_application_master"
24) Added new function "of_set_notification_message" in "wn_controller_master"



Release 2018.2.0.97 Major Release (2018R2) ... March 29, 2018 (GA) PB 2017R2 Build 1769
1)  Migration of entire framework from PB2017R2 Build 1756 to PB2017R2 Build 1769
2)  Optimized all the frameowrks PBL's
3)  Created POSTGreSQL Transaction object ancestor "ns_sqlca_progresql_master"
4)  Added code to Cliked event of "vs_dc_list_master" to speed up sorting
5)  Revised "wn_main_master" object's Open event code to account for running within a Dockable App
6)  Revised "wn_main_master" object's "oe_PostOpen" event to reset visibility when used in a Dockable App
    Note: Improves the instantiation over-head performance by 2-3x!
7)  Revised "of_send_mail" method in "nc_app_controller_master" to check if running within a Mobile App
8)  Revised "of_check_exe_version" method in "nc_app_controller_master" to set the PB IDE Active switch ON if runnning under IDE
9)  Added "of_is_pb_ide_active" method to "nc_app_controller_master" object
10) Added "of_check_ps_version" method to "nc_app_controller_master" object
11) Added code the "nc_app_controller_master" object's Constructor event to log whether App is running M-code or P-code	
12) Added code the "nc_app_controller_master" object's Constructor event to to check for PowerServer verson at start-up
13) Revised the Destructor event in "vs_dc_master" to check if the Object's Classification is valid before save
14) Revised the "oe_postopen" event in "wn_messagebox_master" to adjust image path if running under PB IDE vs from an EXE
15) Created ns_json_generator_master JSON Generator object ancestor.
16) Created ns_json_parsor_master JSON Parsor object ancestor.
17) Created ns_restful_client_master RESTful Client object ancestor.
18) Created ns_http_client_master HTTP Client object ancestor.


Release 2018.1.0.95 Major Release (2018R1) ... February 11, 2018 (GA) PB 2017R2 Build 1756
1)  Migration of entire framework from PB2017MR01 to PB2017R2.
2)  Added code to "fn_open_sheet_window" to track Dockable sheets
3)  Added code to "fn_open_sheet_window_withparm" to track Dockable sheets
4)  Moved SHBrowseForFolder 64bit API in "nc_app_controller_master" to nc_app_controller64_master object
5)  Added new variable to indicate the App is an IWA application in "nc_app_controller_master".	
6)  Revised code to set IWA switch & log status if in DEBUG mode in "nc_app_controller_master".
7)  Added new public function "of_is_iwa_app" in "nc_app_controller_master".
8)  Added new public function "of_set_dockable_mode" in "nc_app_controller_master".
9)  Added new public function "of_is_dockable_app" in "nc_app_controller_master".
10) Added code to the RetrieveEnd event of "vs_dc_graph_master" to handle grap creates in PowerServer Web & Mobile.
11) Added new public function "of_get_document_windows" in "nc_app_controller_master".
12) Added new public function "of_get_tabgroup_windows" in "nc_app_controller_master".
13) Added new public function "of_get_docked_windows" in "nc_app_controller_master".
14) Added new public function "of_get_sheet_windows" in "nc_app_controller_master".
15) Removed all extraneous code. Added instance Window PTR in "wn_debug_list_master".
16) Changed code to use save Instance Window PTR in "wn_debug_list_master".
17) Added code to resize the mle_windows control in "wn_debug_list_master".
18) Added code to Loop through the tracked windows & list them in the MLE in "wn_debug_list_master".
19) Added Trace Model tab page to "wn_debug_list_master".
20) Revised the code to fix the report type if Sheet is also dockable in "wn_main_master" of_get_window_open_type method.
21) Added boolean indicator for tracking being the current Active window in "wn_main_master".
22) Added new public function "of_get_sheet_windows" in "wn_master".
23) Added code to the Activate Event to Set Active Window indicator on focus in "wn_master".
24) Added code to the DeActivate Event to  Set the Active Window boolean to false when losing focus in "wn_master".
25) Added code to Fix for PowerServer Web bug SelectText in "wn_messagebox_master".
26) Revised GUI to present better on W10 & newer O/S versions in "wn_zoom_master".
27) Added code to mark the open state as SHEET for MAIN window types being opened in "fn_open_sheet_as_document".
28) Added code to mark the open state as SHEET for MAIN window types being opened in "fn_open_sheet_docked".
29) Added code to mark the open state as SHEET for MAIN window types being opened in "fn_open_sheet_in_tabggroup".
30) Added code to mark the open state as SHEET for MAIN window types being opened in "fn_open_sheet_withparm_as_document".
31) Added code to mark the open state as SHEET for MAIN window types being opened in "fn_open_sheet_withparm_docked".
32) Added code to mark the open state as SHEET for MAIN window types being opened in "fn_open_sheet_withparm_in_tabggroup".
33) Move 64bit code to the 64bit App Controller object class "nc_app_controller64_master" from "nc_app_controller_master".
34) Added new "ns_http_client_master" base class for the new HTTPCLIENT object class.
35) Added new "ns_json_generator_master" base class for the new JSON Generator object class.
36) Added new "ns_json_parsor_master" base class for the new JSON Parsor object class.
37) Added new "ns_restful_client_master" base class for the new RESTFul Client object class.
38) Added new "of_set_transobject" method to the "ns_ds_master" object class.
39) Added new "of_get_transobject" method to the "ns_ds_master" object class.
40) Added new variables to support "heart beat" feature	in the "ns_sqlca_master" object class.
41) Added new "oe_heart_beat" event to the "ns_sqlca_master" object class.
42) Revised the "of_Connect" and "of_disconnect" methods in "ns_sqlca_master" class for the new HeartBeat feature.
43) Added new "of_set_heartbeat_time" method to the "ns_sqlca_master" object class.
44) Added new "of_set_heartbeat" method to the "ns_sqlca_master" object class.
45) Added code to control the HeartBeat feature if active SQL is found in the SQLPreview event of "ns_sqlca_master".
46) Added Transaction Object pointer and Get/SetTransObject methods to support Parent class pointer.	
47) Revised the "oe_resize" event code in "vs_tc_master" to fix resizing issue.
48) Revised the "resize" event code in "wn_log_viewer_master" to fix resizing for Dockable windowed App	.


Release 2017.3.0.90 Major Release (2017R3) ... December 10, 2017 (GA) PB 2017 Build 1686
1)  Migration of entire framework from PB 2017 to PB 2017MR01.
2)  Changed function fn_number_to_words_cheque to fn_number_to_words.
3)  Added new variables for O/S version and build to nc_app_controller_master
4)  Revisd the code to now retrieve & include O/S build & platform number in of_check_os_version
5)  Changed the script to always write the App's bitness to the log in of_set_pb_environment_info
6)  Added SetCapture() & ReleaseCapture() declarations for better mouse control	in nc_app_controller_master
7)  Added of_is_64bit_os function to  nc_app_controller_master
8)  Created a 64bit Structure for the support of 64bit App's in of_browse_for_folder of nc_app_controller_master
9)  Removed deprecated code in of_write_event of nc_app_controller_master
10) Created new function of_is_64bit_app in nc_app_controller_master
11) Created new function of_is_64bit_processor in nc_app_controller_master
12) Created new function of_check_fc_version in nc_app_controller_master
13) Added ib_check_fc_version switch to check for STD Framework verson at start-up in nc_app_controller_master
14) Added ii_keyboardtype for Appeon 2016 / PB2017 Universal compliance in vs_dc_master
15) Added new variables for new Appeon Mobile features in PB 2017 Universal in vs_em_master
16) Added recognition timer variable for Appeon 2016 / PB2017 Universal compliance in vs_ip_master
17) Moved Hint Text support to oe_postconstructor in vs_sle_master
18) Revised the code to use of_sethinttext from the AWS object vs appeonextfuncs in vs_sle_master
19) Added ii_vertical variable for compaibility with Appeon 2016 / PB 2017 Universal in vs_st_master
20) Revised mouse pointer handling in fn_print_screen
21) Created new fn_print_window global function
22) Added DataStore to collect Menu activity statistics in mu_master
23) Added GetMenuString() & GetMenuItemInfo() method for menu activity capture in nc_app_controller_master
24) Added code to fire the RowFocusChanged if row highlighting is in effect in vs_dc_list_master
25) Added the ability to show a print dialogue in in vs_dc_master
26) Revised the code to print more effectively under W10 & also with Cancel dialogue in wn_master
27) Added new oe_print_screen event in wn_master
28) Added code to fire the "oe_preDestructor" menu event in wn_master
29) Removed the "pc_icon" & "st_msg" controls as the DWO now handles this in wn_messagebox_master
30) Revised default control properties for PB2017MR01 optimization vs_rte_master
31) Revised to allow the TXT file to created dynamically via DWO's default primary buffer in wn_tracing_options_master
32) Moved the code from the Constructor to the Post Constructor of the DC in wn_tracing_options_master
33) Revised to allow the TXT file to created dynamically via DWO's default primary buffer in wn_tracing_options_master
34) Revised code to mark the window as now being used as an MDI Sheet in fn_open_sheet_window
35) Added code to indicate that the window was opened as a Sheet (MDI Child) in fn_open_sheet_window_withparm
36) Added code to record the fact that the user clicked this enu item in mu_application_master
37) Added menu and menu item pointers in mu_master
38) Added new function of_set_controller_window_class to nc_app_controller_master
39) Over-Rode the Ancestor to stop annoying messages in wn_log_viewer_master
40) Added new of_get_document_state function in wn_main_master
41) Added new of_get_tabgroup_state function in wn_main_master
42) Added new of_get_docked_state function in wn_main_master
43) Added new of_set_docked_state function in wn_main_master
44) Added new of_set_document_state function in wn_main_master
45) Added new of_set_sheet_state function in wn_main_master
46) Added new of_set_tabgroup_state function in wn_main_master
47) Added new of_get_sheet_open_state function in wn_main_master
48) Added new of_get_window_open_type function in wn_main_master
49) Added code to set the open state tracking indicator	in fn_open_sheet_as_document
50) Added code to set the Document state indicator in fn_open_sheet_docked
51) Added code to set the TabGroup state indicator in fn_open_sheet_in_tabggroup
52) Added code to set the document state indicator in fn_open_sheet_withparm_as_document
53) Added code to set the Docked state indicator in fn_open_sheet_withparm_docked
54) Added code to set the Tab Group state indicator in fn_open_sheet_withparm_in_tabggroup


Release 2017.2.0.76 Major Release (2017R2) ... July 17, 2017 (GA) PB 2017 Build 1666
1)  Migration of entire framework from PB 12.6 to PB 2017.
2)  Added support for 64bit application processing.
3)  Added "AddFontResourceEx" and "RemoveFontResourceEx" font API's to nc_app_controller_master
4)  Added "ib_pdf_native" switch to support PB 2017's new native PDF feature to nc_app_controller_master
5)  Revised code in nc_app_controller_master "of_get_dbms_version" method to use INI file
6)  Revised code in nc_app_controller_master "of_set_pbdebug_on" method to support PB 2017
7)  Revised code in nc_app_controller_master "of_set_pbdebug_output_file_name" method to support PB 2017
8)  Revised code in nc_app_controller_master "of_set_pbdebug_delete" method to support PB 2017
9)  Revised code in nc_app_controller_master "of_set_pbdebug_option" method to support PB 2017
10) Revised code in nc_app_controller_master "Constructor" for "expected" db version from INI file
11) Revised nc_app_controller_master to add ib_pdf_native switch for native PDF support in PB 2017
12) Revised ns_ds_master to add ib_pdf_native switch for native PDF support in PB 2017
13) Revised ns_ds_master "oe_postconstructor" method to manage Native PDF Gen in PB 2017
14) Added ns_ds_master "of_set_pdf_native" method to support Native PDF Gen in PB 2017
15) Added ns_ds_master "of_get_pdf_native" method to support Native PDF Gen in PB 2017
16) Revised ns_ds_master "RetrieveEnd" method to support Native PDF Gen in PB 2017
17) Revised ns_dc_master to add ib_pdf_native switch for native PDF support in PB 2017
18) Revised ns_dc_master "oe_postconstructor" method to manage Native PDF Gen in PB 2017
19) Added ns_dc_master "of_set_pdf_native" method to support Native PDF Gen in PB 2017
20) Added ns_dc_master "of_get_pdf_native" method to support Native PDF Gen in PB 2017
21) Revised ns_dc_master "RetrieveEnd" method to support Native PDF Gen in PB 2017


Release 2017.1.0.73 Major Release (2017R1) ... May 17, 2017 (GA) PB 12.6.0 Build 4108
1)  Migration of entire framework from PB 12.1 to PB 12.6.
2)  Added new "of_set_column_refocus" method and ib_column_refocus variable to vs_dc_detail_master.
    - If the boolean is set to TRUE, framework restores column focus after a retrieve ().
3)  Added code to vs_dc_detail_master RetrieveStart event to support the column refocus feature.
4)  Added code to vs_dc_detail_master RetrieveEnd event to support the column refocus feature.
5)  Removed old "Skin" menu items from mu_master. 
    - PB.Net and WPF are no longer supported.
6)  Updated frmework version information in nc_app_controller_master
7)  Added new "fn_open_sheet_as_document" global function to support dockable windows.
8)  Added new "fn_open_sheet_docked" global function to support dockable windows.
9)  Added new "fn_open_sheet_in_tabggroup" global function to support dockable windows.
10)  Added new "fn_open_sheet_withparm_as_document" global function to support dockable windows.
11)  Added new "fn_open_sheet_withparm_docked" global function to support dockable windows.
11)  Added new "fn_open_sheet_withparm_in_tabggroup" global function to support dockable windows.
12)  Added System Function object pointer (io_sf) for ease of programming to the following objects:
     - ns_ado_rs_master, ns_ado_rs_master, ns_context_information_master, ns_context_keyword_master,
	ns_corbaunion_master, ns_errorlogging_master, ns_exception_master, ns_jagorb_master,
	ns_mlsync_master, ns_olestorage_master, ns_olestream_master, ns_olexnobject_master,
	ns_pipeline_master, ns_service_master, ns_ssl_callback_master, ns_ssl_service_provider_master,
	ns_throwable_master, ns_trace_file_master, ns_trace_tree_master, ns_trans_server_master,
	ns_ulsync_master, vs_an_master, vs_hsb_master, vs_ie_master, vs_ole_master, vs_rte_master,
	vs_vsb_master
13)  Revised mu_master base ancestor to comply with W10 look & feel.
14)  Revised mu_popup_master ancestor menu to comply with W10 look & feel.


Release 2016.3.0.68 Major Release (2016R3) ... October 10, 2016 (GA) PB 12.1.0 Build 6518
1)  Revised the "nc_app_controller_master" NVUO to only open the HOLD window 
    if a Controller type window is being used.
2)  Added "oe_print_window" event to the "vs_dc_master" DataWindow base class.
3)  Added "of_get_print_window_status" function to the "vs_dc_master" DataWindow base class.
4)  Added "IsWindowEnabled" external function declaration to the "nc_application_master" base class.
5)  Added "mu_application_extension" extension class.
6)  Added "mu_extension" extension class.
7)  Added "nc_extension" extension class.
8)  Added "ns_ds_extension" extension class.
9)  Added "vs_dc_extension" extension class.
10) Added "wn_extension" extension class.
11) Added "wn_response_extension" extension class.
12) Added "RtlGetVersion" SDK API to the "nc_app_controller_master" base class.
13) Revised "of_check_os_version" function in the "nc_app_controller_master" base class to
    acquire the correct O/S version (PB 12.6 workaround Environment bug).
14) Various small code tweaks for better performance under the Appeon 2016 product release.


Release 2016.2.0.65 Major Release (2016R2) ... June 30, 2016 (GA) PB 12.1.0 Build 6518
1)  Revised the "nc_app_controller_master" NVUO, changed the HALT command to a HALT Close to ensure these events fire where possible.
2)  Revised the "nc_app_controller_master" NVUO, added code to support he new "FreeDBLibraries" INI file entry.
3)  Revised the "nc_app_controller_master" NVUO "systemError" event to prevent recursive errors on another failure.
4)  Created a new global function "fn_number_to_words_cheque" to convert numbers to English Text (ie: for cheque writing).
5)  Revised the "wn_master" base ancestor Window Class to support Mouse Wheel scrolling in native & web environments!
6)  Revised the "fn_open_sheet_window" function to only log when in DEBUG mode.
7)  Revised the "fn_open_sheet_window_withparm" function to only log when in DEBUG mode.
8)  Revised the "fn_open_tab_page" function to only log when in DEBUG mode.
9)  Revised the "fn_open_tab_page_withparm" function to only log when in DEBUG mode.
10) Revised the "fn_open_user_object" function to only log when in DEBUG mode.
11) Revised the "fn_open_user_object_withparm" function to only log when in DEBUG mode.
12) Revised the "fn_open_window" function to only log when in DEBUG mode.
13) Revised the "fn_open_window_withparm" function to only log when in DEBUG mode.
14) Revised the "nc_app_controller_master" NVUO, Added & Revised API declarations to add O/S Event logging methods.
15) Revised the "nc_app_controller_master" NVUO, Added DEP and Printer API's to the list of declarations.
16) Revised the "nc_app_controller_master" NVUO, Added new/revised API declarations from the Web Service framework.
17) Revised the "nc_app_controller_master" NVUO, Added MS-Windows EVENT log start message.
18) Revised the "nc_app_controller_master" NVUO, Added code to add Registry entries for MS-Windows event viewer.
18) Revised the "nc_app_controller_master" NVUO, Added code to log the end of application processing in the O/S event log.
19) Revised the "nc_app_controller_master" NVUO, Added code to log a System Error in the O/S event log when this event occurs.
20) Revised the "nc_app_controller_master" NVUO, Modified code to utilize language specific version of the Logon dialogue!
21) Revised the "nc_app_controller_master" NVUO, Revised the code to log Check Version information only when in DEBUG mode.
22) Revised the "nc_app_controller_master" NVUO, Revised code to suppress logging of Environment information unless in DEBUG mode.
23) Revised the "nc_app_controller_master" NVUO, Added new "of_get_mobile_device_id" method to return the Mobile Device ID to the application.
23) Revised the "nc_app_controller_master" NVUO, Added new "of_get_mobile_company" method to return the Mobile device's company information.
24) Revised the "nc_app_controller_master" NVUO, Added new "of_write_event" *overloaded* method for SDK support.
25) Revised the "nc_app_controller_master" NVUO, "of_set_dep_policy" method allowing the application to over-ride the Data Execution Prevention state.
26) Revised the "nc_app_controller_master" NVUO, Added new "of_get_mobile_platform" method to allow the application to query the Mobile PlatForm type.
27) Revised the "nc_app_controller_master" NVUO, Added new "of_get_mobile_os" method to allow the application to query the Mobile OS type.
28) Revised the "nc_app_controller_master" NVUO, Added new "of_set_debug_mode" method to allow the application to change the DEBUG mode dynamically.
29) Revised the "nc_app_controller_master" NVUO, Revised "of_get_message" method to switch DWO's for proper language support!
30) Revised the "vs_dc_master" control, adding a new "oe_selectall" event to support selection of all the text in the current column!
31) Revised the "vs_dc_master" control, adding a new "of_get_saveas_status" method to support queryong of the SaveAs required switch.
32) Revised the "wn_debug_list_master" Window, Added code to handle the new DEBUG command button.
33) Revised the "wn_main_master" Window, Added new "of_is_sheet_window" method to query if Window is operating as an MDI_Child (Sheet).
34) Revised the "wn_main_master" Window, revised OPEN event code to Revised the code to align with Appeon Mobile version 2015R1 and higher.
35) Revised the "wn_main_master" Window, revised CLOSE event code to only log when in DEBUG mode.
36) Revised the "wn_messagebox_master" Window's OPEN and oe_PostOpen events to support displaying information via a DataWindow.
37) Revised the "wn_response_master" Window, to Removed the default (hard coded) Menu instantiation.
38) Revised the "wn_messagebox_master_e/f/s/i" Windows, to handle proper Menu instantiation in the user's language.



Release 2016.1.1.59 Service Pack (2016R1-1) ... April 26, 2016 (GA) PB 12.1.0 Build 6518
1)  Replaced old MessageBox( ) PB method with the frameworks "of_messagebox" standard in the following ...
    nc_app_controller_master.of_set_splash_window
    nc_app_controller_master.constructor
    nc_network_adapter.of_getadaptersinfo
    nc_wininet_master.ue_internetopen
    vs_dc_master.of_check_data
    wn_controller_master.open
    wn_master.of_set_updatable
    vs_ole_master.error
2)  Updated the "of_messagebox" method in the "nc_app_controller_master" base class to bypass the logic if in "Silent" mode.


Release 2016.1.0.58 Major Release (2016R1) ... March 23, 2016 (GA) PB 12.1.0 Build 6518
1)  New LINE base class created - "vs_ln_master".
2)  New OVAL base class created - "vs_ov_master".
3)  New ROUNDRECTANGLE base class created - "vs_rrt_master".
4)  New RECTANGLE base class created - "vs_rt_master".
5)  Added more external Function declarations to the Application Controller base class (nc_app_controller_master).
6)  Added new Android, iOS, Windows & AWS version tracking variables to the Application Controller base class.
7)  Created new INI file default entries for the the Android, iOS, Windows & AWS version tracking variable value.
8)  Added code to check the OS version based on the environment (Web/Native/Mobile) to the Application Controller base class.
9)  Removed references to the old PocketPC/PocketBuilder variables in the Application Controller base class.
10) Added a new function (of_check_aws_version) to validate the AWS version in the Application Controller base class.
11) Added code to the "of_get_appeon_environment_info" function to validate the AWS version in a Mobile environment.
12) Added code to the Applciation Controller base class' Constructor to initialze & process new INI values.
13) Added new function "of_base64_stringtobinary" to the nc_crypto_master base class.
14) Added new function "of_base64_binarytostring" to the nc_crypto_master base class.
15) Removed external references to the "Crypto32" and "CW3220" DLL's in the nc_crypto_master base class.
16) Removed the "Crypto32.DLL" and "CW3220.DLL" files from the framework!
17) Added new Event "oe_graph_create" to the ns_ds_master DataStore base class.
18) Added new Event "oe_html_context" to the ns_ds_master DataStore base class.
19) Added new Event "oe_filter_activated" to the vs_dc_master DataWindow Control base class.
20) Added new Event "oe_sort_activated" to the vs_dc_master DataWindow Control base class.
21) Added new Event "oe_erase_background" to the vs_dc_master DataWindow Control base class.
22) Added new Event "oe_graph_create" to the vs_dc_master DataWindow Control base class.
23) Added new Event "oe_backtab_out" to the vs_dc_master DataWindow Control base class.
24) Added new Event "oe_html_context" to the vs_dc_master DataWindow Control base class.
25) Added new Event "oe_message_text" to the vs_dc_master DataWindow Control base class.
26) Added new Event "oe_print_margin_change" to the vs_dc_master DataWindow Control base class.
27) Added code to the vs_dc_master RetrieveStart Event base class to support "oe_graph_create event in Appeon!
28) Revised Resize logic in "wn_splash_master" base class to account for different rendering in PB vs Web/Mobile.
29) Rebuilt the framework's documentation set using VisualExpert 2015 build 2015.0.15.1109
30) Framework documentation now avaialble as a separate ZIP file


Release 2015.5.0.50 Service Pack (2015R5) ... December 14, 2015 (GA) PB 12.1.0 Build 6518
1)  Revised the "nc_app_controller_master" NVUO, adding in support for SYSTEM TRAY processing option flag.
2)  Revised the "wn_controller_master" Window, adding in support for SYSTEM TRAY processing.
3)  Created new "mu_systemtray_master" menu to support System Tray functionality when activated.
4)  Created new "nc_systemtray_master" abstract class to handle all SYSTEM TRAY processing!
5)  Revised the "wn_controller_master_i" abstract Window to inherit from the correct ancestor.
6)  Revised the "ns_internet_master" NVUO to correct the data type of the returned "Long".
7)  Revised the "mu_application_master" menu, adding a new menu item to support the new System Tray functionality.


Release 2015.4.1.49 Service Pack (2015R4-2) ... October 27, 2015 (GA) PB 12.1.0 Build 6518
1)  Revised "fn_open_sheet_window_withparm" function to log the Window HANDLE being OPENED.
2)  Revised "fn_open_window" function to log the Window HANDLE being OPENED.
3)  Fixed display formatting issues with Messages #94 & #95
4)  Renamed the "of_create_instance" method to "of_create_ejb" to better define the action being performed.
5)  Revised the "vs_dc_master" base class to support Synchronized Zooming".
6)  Revised the "wn_master" base class to support Synchronized Zooming".
7)  Revised "wn_master" class to log the Window HANDLE being CLOSED.
8)  Revised "nc_app_controller_master" class to log the O/S Command Line information being passed into the application.

Release 2015.4.1.45 Service Pack (2015R4-1) ... October 06, 2015 (GA) PB 12.1.0 Build 6518
1)  Code clean-up and library optimization.
2)  Fix for possible NULL Window class title that will crash PB 12.6
3)  New code to log more information about the Mobile, Web or PB environmrnt at applciation start-up.
4)  Fix for the "of_Browse_For_Folder" method.

Release 2015.4.0.43 Service Pack (2015R4) ... September 23, 2015 (GA) PB 12.1.0 Build 6518
1)  Added code to "FN_Open_Sheet_Window_WithParm" to check if the "base" name object class is being passed in.
2)  Revised the code in "FN_Open_Tab_Page" class to log the proper class name being opened.
3)  Revised the code in "FN_Open_Tab_Page_WithParm" class to log the proper class name being opened.
4)  Created a new global function "FN_Open_User_Object" to handle generic User Object instantiation.
5)  Created a new global function "FN_Open_User_Object_WithParm" to handle generic User Object instantiation.
6)  Revised "FN_Open_Window" class to log the proper class name being opened.
7)  Revised "FN_Open_Window_WithParm" class to log the proper class name being opened.
8)  Added new instance variables to the "nc_app_controller_master" class as follows:
    -  Added ib_offline flag to allow support to take the application "Offline" for maintenance.
    -  Added new JVM Class to handle JavaVM processing capabilities.
    -  Added new "STD_FC_PB_EJB" PBL library to allow framework compiles for JVM entities.
9)  Revised the "oe_open" event of the "nc_app_controller_master" class to handle the OFFLINE condition.
10) Added code in the "Destructor" event of the "nc_app_controller_master" class to handle the JVM.
11) Revised the "Constructor" event of the "nc_app_controller_master" class to handle the OFFLINE condition.
12) Revised the "wn_master" class' "oe_print_window" event to use the current Window's coordinates for printing.
13) Added a new "oe_syscommand" event to the "wn_master" class' to allow low-level O/S notifications to be monitored.
14) Revised the "wn_splash_master" class' "Timer" event to close the current dialogue sooner and not interfere with any animation.
15) Revised the "mu_application_master" class to handle the DEBUG menu option when in DEBUG mode.
16) Revised the "oe_close" event of the "nc_app_controller_master" class to close the Application Profile Tracing file if active.
17) Revised the "of_set_application_location" method of the "nc_app_controller_master" class to use a "/" at the end to conform to MOBILE standards.
18) Added the "of_get_profiler_trace" and "of_set_profiler_trace" methods to the "nc_app_controller_master" class to handle Application Profiling!
19) Added the "of_createjavavm" and "of_createinstance" methods to the "nc_app_controller_master" class to handle Java Class interaction!
20) Added code to the "DropDown" event of the "vs_dp_master" class to "Work Around" a Calendar display issue when the WeekNumber property is requested!
21) Added new "Profiling" CB to the "wn_debug_list_master" class to support Application profiling!
22) Revised the "oe_PostConstructor" event of the "wn_log_viewer_master" class to fix issues in Appeon Mobile.
23) Revised the "oe_Delete" event of the "wn_master" class to return a completion code.
24) Added new "of_display_profile_information" method to the "nc_app_controller_master" class to new "Application PROFILE" display dialog (wn_profile_master).
25) Revised the "Key" event of the "nc_app_controller_master" class to Open the new "Application PROFILE" display dialog on CTRL+SHIFT+F2.
26) Created a new "wn_profile_master" class to enable/disable "Application PROFILE" tracing at any time in the PB Application.
27) Fixed an ImportFile ( ) issue with the "wn_log_viewer_master" window class so that the LOG would be viewable on Android devices (Appeon 2015.0328.00)!


Release 2015.3.0.40 Service Pack (2015R3) ... June 23, 2015 (GA) PB 12.1.0 Build 6518
1)  Added new "of_notification_display" method to the Application Controller (nc_app_controller_master) base class.
2)  Added new "of_notification_remove" method to the Application Controller (nc_app_controller_master) base class.
3)  Revised "oe_help" event of "vs_dc_master" base class to use the new "of_notification_display" Application Controller method.
4)  Removed the old PocketBuilder "of_set_nb_message" method from the "wn_master" base Window class.
5)  Replaced hard coded message text in the "nc_app_controller_master" Application Controller base class.
    - The AC now utilizes the Message Sub-System to deoliver messages!
6)  Revised the "vs_dc_master" DW Control base class to issue more informative messages in the following events:
    - Error, DBError, ItemError, WSError and SQLPreview
7)  Revised the "ns_dS_master" DataStore base class to issue more informative messages in the following events:
    - Error, DBError, ItemError, WSError and SQLPreview
8)  Revised the "ns_sqlca_master" Transaction base class to issue more informative messages in the following events:
    - DBError and DBNotification
9)  Added new message numbers 72-93 and text to the message sub-system
10) Revised "vs_dc_webservice_master" abstract class to utilize the new "ns_ws_connection_master" Connection base class.
11) Revised "ns_ds_webservice_master" abstract class to utilize the new "ns_ws_connection_master" Connection base class.
12) Added a new "Web Service DataWindow Section" to the default Application INI file (see changes #10 & #11).
13) Revised the events in the "nc_app_controller_master" class to use the help sub-system for message text, as follows ...
    - oe_systemerror, constructor, oe_close
14) Revised the methods in the "nc_app_controller_master" class to use the help sub-system for message text, as follows ...
    -  of_set_affinity, 
15) Added new instance variable "is_hint_text" to the "vs_sle_master" base class for Appeon Mobile's of_SetHintText method.
16) Fixed a bug in the "wn_master" base class to call the related menu's "of_ok2save" method when it is notified!
17) Changed the "of_display_basic_help" method in the "" class to no longer use the old XP "WinHelp.hlp" help.
18) Modified the ""oe_postconstructor" event of "mu_application_master" class to set the related Colour, Log & SMC menu properties.
19) Modified the ""oe_postconstructor" event of "mu_main_master" class to set the Colour, Log & SMC menu item state properly.
20) Added new "About" tab page ancestors in the English, French, Spanish and Italian PBL's.
21) Added new "About" tab control ancestors in the English, French, Spanish and Italian PBL's.
22) Fixed the "Device" about tab page code to correctly display the device ID in the Mobile environment.
23) Revised the "wn_response_master" base class to bypass any ChangeMenu processing on the Mobile platform.
    - Menus are handled differently by Appeon's AWS on the mobile device.
24) Updated the example OrderEntry application using the latest Integrated framework build and added Italian support!


Release 2015.2.0.35 Service Pack (2015R2) ... June 10, 2015 (GA) PB 12.1.0 Build 6518
1)  Added new "ns_ws_connection_master" Web Service Connection base class.
2)  Added new "nc_thread_execution_master" base class for Multi-threading support.
3)  Added new "nc_thread_postback_master" base class for Multi-threading support.
4)  Added new "of_get_appl_data_path" method to the "nc_app_controller_master" base class.
5)  Added new "of_get_appl_temp_path" method to the "nc_app_controller_master" base class.
6)  Replaced Log Wrap Integer with a Long data type in the "nc_app_controller_master" base class.
7)  Added new "STD_FC_PB_Base_i.pbl" PB Library to support Italian.
    => Many thanks to Gimmy Susan for the Italian transations & testing!
8)  Added a New global function "FN_NVL" added that implememts the "NULL VALUE" DBMS command in PB.
9)  Added a New global function "FN_IIN" added that implememts the "IN" DBMS command in PB.
10) Added a New INI value "Log_Wrap" (Y/N) that enables/disables Log File wrapping.
11) Added a New INI value "Log_Wrap_Size" (NNNNNNNN) - threshold when Log File wrapping is active.
12) Added a New "vs_dc_webservice_master" class to handle Web Service DWO's inside a DW Control.
13) Added a New "ns_ds_webservice_master" class to handle Web Service DWO's inside a DataStore.



Release 2015.1.0.31 Major Release (2015R1) ... April 30, 2015 (GA) PB 12.1.0 Build 6518

1)  Version number change in "nc_app_controller_master" to match new release numbering scheme.
    =>  Release numbering scheme changed to YYYY(Rn) = Year + Release#



Release 5.6.0.30 Changes ... April 29, 2015  (SP06)  PB 12.1.0 Build 6518
========================================================================

1)  Fixed an issue with the "wn_validate_master" window to not error on close.
2)  Added PageUp and PageDown keyboard control on the RTE Control base ancestor.
3)  Added support in "nc_app_controller_master" for the new "ActiveDirectory" Keyword in the INI file 
4)  Created new "fn_xml_symbolic_replace" function to replace ANSI values with their XML escape codes.
5)  Created new "fn_xml_ansi_replace" function to replace XML escape codes with their ANSI character.
6)  Added support in "nc_app_controller_master" to handle Log Wrapping.
7)  Changed the nc_app_controller_master "of_write_file" function from Public to Private.
8)  Fixed code in the "nc_powershell_master" to only log the command when in Debug mode
9)  Revised the "vc_tp_about_mobile" object code to enable visibility when active in a Mobile device
10) Revised the "vc_tp_about_web" object code to make the control visible if in a Web application.
11) Added support in "nc_app_controller_master" to get the application's IP address if running natively.
12) Added support in "nc_app_controller_master" to check if ActiveDirectory processing is "required".
13) Removed all non-essential object classes from the "STD_FC_PB_Appeon.pb" PBL
14) Revised the "wn_log_viewer_master" DC object code to Return "2" to suppress error messages on Import()!
15) Added new "nc_system_tray_master" class to allows PB applciations to reside in the MS-Windows "System Tray".
16) Renamed class "ns_dda_master" to "ns_sqldda_master" for naming standards.
18) Renamed class "ns_dsa_master" to "ns_sqlsa_master" for naming standards.
19) Renamed class "ns_transaction_master" to "ns_sqlca_master" for naming standards.
20) Renamed class "ns_transaction_ase_master" to "ns_sqlca_ase_master" for naming standards.
21) Renamed class "ns_transaction_db2_master" to "ns_sqlca_db2_master" for naming standards.
22) Renamed class "ns_transaction_informix_master" to "ns_sqlca_informix_master" for naming standards.
23) Renamed class "ns_transaction_oracle_master" to "ns_sqlca_oracle_master" for naming standards.
24) Renamed class "ns_transaction_sa_master" to "ns_sqlca_sa_master" for naming standards.
25) Renamed class "ns_transaction_sqlite_master" to "ns_sqlca_sqlite_master" for naming standards.
26) Renamed class "ns_transaction_ss_master" to "ns_sqlca_ss_master" for naming standards.
27) Added a new PBL () to house deprecated objects for each release of the FOundation Classes
    - Located in the "Deprecated" folder of the Framework.
28) Renamed class "nc_active_directory" to "nc_active_directory_master" for naming standards.
29) Revised "nc_app_controller_master" class "of_display_help" method to use iNET object for help file resolution in Web/Mobile.



Release 5.5.0.23 Changes ... January 21, 2015  (SP05)  PB 12.1.0 Build 6518
========================================================================
1)  Fixed an issue with detecting O/S bitness properly.
2)  Fixed an issue with detecting Application bitness when compiled as a 64 EXE (PB 12.6 Classic only).
3)  Added new method "of_get_os_bitness" that returns the O/S bitness.
    Note: If Appeon Web - returns the Web Browser bitness (see #6).
4)  Added new method "of_get_os_temp_path" that returns the current TEMP work area O/S setting.
5)  Added new method "of_get_appl_bitness" that returns the current EXE's compiled bitness (32 or 64).
6)  When instantiated as an Appeon Web application the Application & O/S bitness is set to the Web Browers bitness
7)  Added new Window base Class "wn_validate_master" to handle Active Directory Login processing.
8)  Added AJAX image to the "wn_logon_master" Window base class to display/animate when waiting for the DBMS.


Release 5.4.0.21 Changes ... December 19, 2014  (SP04)  PB 12.1.0 Build 6518
========================================================================
1)  Removed old reference variable "_PtrData" from object source code that could cause C++ compiler errors.
2)  Removed old reference variable "Handle" from object source code as its a PB reserved word.
3)  Removed old reference variable "Anchor" from object source code as its a PB reserved word.
4)  Added support for dynamic PBDEBUG feature for PowerBuilder 12.6
5)  Added new "oe_resize" event to the wn_master base ancestor class.
    -  This event ONLY fires when the user lets go of the mouse vs the PB resize that fires for every pixel!
6)  Added a new "vs_cb_ok_master" class that defaults the look & feel and behaviour of an OK button.
7)  Added a new "vs_cb_cancel_master" class that defaults the look & feel and behaviour of a CANCEL button.
8)  Added new "oe_ok" event to the base window class "wn_master".
9)  Added new "oe_cancel" event to the base window class "wn_master".
10) Fixed the "vc_tp_about_support" class for the proper refrence to the active DataBase name.
11) Added new Transaction Object classes for the following DBMS: SQLServer, Oracle, DB/2, and Informix.
12) Updated the STD_FC_PB_Appeon PBL for method signatures to match Appeon 2013R2 & 2015 releases.
13) Removed deprecated Appeon Class "eon_mobile_recorderex" from STD_FC_PB_Appeon PBL.
14) Added new "of_set_current_tabpage" method to the "vs_tc_master" base class for Tab Control's.
15) Added new "of_get_current_tabpage" method to the "vs_tc_master" base class for Tab Control's.
16) Framework system tested with:
    - PowerBuilder 12., 12.5.1 and 12.6.
    - Appeon 2013R2 and 2015.
    - iOS 8.1 and Android 5.0.1


Release 5.3.0.14 Changes ... July 11, 2014  (SP03)  PB 12.1.0 Build 6518
========================================================================
1)  Corrected RHMB script on base DataWindow control to display the pop-up menu properly at the mouse pointer location when the parent Window is of type "Response".
2)  Added "Centering" logic to the base CHILD window "wn_child_master" to center off the "Controller" window when active.
3)  Fixed a BUG in the Tab Page base ancestor "nc_tp_master" that fired the "oe_postconstructor" event twice!
4)  Revised the centering logic on the base RESPONSE window "wn_response_master" to optimize the behaviour.
5)  Added "Centering" logic to the base POPUP window "wn_popup_master" to center off the "Controller" window when active.
6)  Added window "registration" logic to the base CHILD window "wn_child_master" to allow the Controller to track its resources.
7)  Fixed the base ancestor MAIN window "wn_main_master" to correct a register/Unregister issue with the active "Controller" window.
8)  Fixed the base ancestor CHILD window "wn_child_master" to correct a register/Unregister issue with the active "Controller" window.
9)  Fixed the base ancestor POPUP window "wn_popup_master" to correct a register/Unregister issue with the active "Controller" window.
10) Added "parent" object registration to all STANDARD NON-VISUAL objects via an "of_register" method!
11) Fixed a formatting bug in the SQL trace of the TRANSTION and DATASTORE base ancestor objects.
12) Added default boolean, long and Integer instance work variables to all STANDARD NON-VISUAL objects.
13) Added error event logging to the web service CONNECTION object base ancestor (ns_connection_master).
14) Revised PB version checking to be INI driven versus hard coded.
15) Added new "PB_Version=" parameter to the base INI file & related code in the supporting classes
16) Added a new "of_is_copy" method to the base transaction object (ns_transaction_master).



Release 5.2.0.10 Changes ... March 31, 2014  (SP02)  PB 12.1.0 Build 6518
=========================================================================
1) Added new code to the visual OLE container's (vs_ole_master) "externalexception" event.
2) Added new code to the visual OLE container's (vs_ole_master) "error" event.
   Note: Items #1 & #2 bring the visual OLE container to be at par with its non-visual counter-part.
3) Removed old Webform and WPF code from the abstract Window classes "wn_controller_master" and "wn_main_master".
4) Corrected code in the base wn_master class that sets the Window titles on the PB aplication's tool bar RHMB
   Note: Code was broken during the creation of the "integrated" framework.
5) Toolbar pop-up menu item text now translated properly into alternate langauges
6) Abstract window class wn_zoom_master controls enalrged to allow easier gesture control when running on Tablets and Smartphones.
7) Error handling code improved on the DataWindow and DataStore base classes
8) Removed unecessary duplicate object class "wn_log_viewer" from the English, French and Spanish PB Libraires.  
9) Added new messages to the base message DataWindow "dw_messages_e /f /s"
10) Added new "Filter" option to the "Log viewer" class (wn_log_viewer_master".
11) Unit tested all code changes with PB 12.1 build 6518, PB 12.5.1 build 4015 and Appeon 2013R2 ( Build 0110.00 - 64 bit)
12) Web Tested on IE 10 & 11
13) Mobile tested on iO/s iPad4 and Android based Nexus 10
14) Application Controller changed to check the Application Object's class mappings (ie: Error, Message, SQLCA, etc)
    If these mappings do not point to the STD FC's objects, mapping errors will be logged and a message displayed.
15) The Calendar base object "wn_calendar_master" now has an English, French and Spanish extension
16) The "wn_calendar_master" was changed to allow either a String or Structure to pass the intial date.
17) THE "VGA" INI parameterand its associated code was removed from the FC's.
     (this was only used for Pocket PowerBuilder which is now deprecated).
18) Fixed a bug handling the "Debug_Mode=" INI file setting
19) Changed the Appeon INI setting in the default INI file to use the "Logging" keyword.
20) Added code to the FC's Logging feature to also simultaneously write to the Appeon Log file if "Logging=Y" in the APPEON section.
21) New "oe_std_fc" event added to the Message, Transaction, Error, SQL Stage, and SQL Description base classes.
22) New "of_get_HPos" method added to the DataWindow Control base class to allow DC's to get the amount the user has already
    scrolled the DW object inside the control.
23) Added new "of_log" to the "ghost" appeonextfuncs object in the "STD_FC_PBAppeon.pbl" to match the updated Appeon WorkArounds.pbl
    (This is to ensure Appeon2013R2 compatability).
24) The PB.NET version of the framework was officially deprecated and is no longer supported!



Release 5.1.0.05 Changes ... January 12, 2014 (SP01)  PB 12.1.0 Build 6518
==========================================================================
1)	Added new MessageBox Window (wn_message_box_master) to replace MS-Windows MessgaeBox dialogue
2)	Added new "of_messagebox) method to the Applciation Controller that integrates with the new MB dialogue.
3)	Added & refined the built-in English, Spanish abd French translations.
4)      Added a new "nc_active_Directory" NVUO that brokers communications with the your MS-Windows, Novell, etc AD Server
5)	Fixed the "oe_exit" user event code in the master controller window (wn_controller_master).
6) 	Continued to remove old PocketBuilder & WPF code.
7) 	Added ToolTip support for DataWindow objects in Appeon Web (not supported natively).
8)	Removed unused menu item "M_0" from mu_application_master.
9)	Removed WEBFORM "Project" object (no longer used).
10)	Moved all internal FC images to a new "Images" sub-folder.
11)	Moved all internal FC DLL's to a new "DLL" sub-folder.
12)     New "VE" folder that now contains all the automated framework documentation in web browser format
        - Generated by VisualExpert
13)     New "OOM" Folder that now contains an Object Oriented Model (OOM) of the IIs framework
        - Generated by PowerDesigner
        Note: To view the OOM, use the free PowerDesigner Viewer.
              PD Viewer download link:  https://global.sap.com/campaign/ne/sybase/powerdesigner16_viewer/index.epx?kNtBzmUK9zU


Release 5.0.0.01 Changes ... September 16, 2013 (GA) PB 12.1.0 Build 6518
=========================================================================
1)	Removed all SIP events (PocketPC) from the framework (not required for Appeon Mobile)
2)	Removed more old WPF, Webforms & PocketBuilder deprecated code.
3)	Added boolean, integer and long work variables to ancestor base menu
4)      	Completed the French and Spanish message translations for MSG ID's 56-60
5)	Various Appeon Web container CVUO fixes.
6) 	Started to remove N/A WPF code.


**  New release numbering scheme in effect **



Release 12.1.0 Changes ... July 29, 2013  RC3

1)	Added new oe_lock_device event to the base ancestor window.
2)	Removed more old WPF, Webforms & PocketBuilder deprecated code.
3)	Removed extraneous resizing code from wn_master base ancestor window.
4)      	"OrderEntry" sample application's Splash Screen now displays Appeon environments.
5)	Appeon Web container CVUO fixes.
6) 	Changed abstract LOG Display dialog to size & center better in the browser.

Release 12.1.0 Changes ... July 23, 2013  RC2

1)	Added new oe_validate event to base ancestor window.
2)	Removed more old PocketBuilder deprecated code.
3)	Added new vc_web_container_master object for Appeon Web.
4)      	Added new vc_web_layout_master object for Appeon Web.
5)	Miscellaneous minor fixes.


Release 12.1.0 Changes ... July 08, 2013  RC1

1)	Consolidated the PB, PK, Appeon Web and Appeon Mobile code lines.
2)	Removed PocketBuilder deprecated code line.
3)	Optimized various code segments for better performance 
4)      	Removed WebForms  deprecated code line.
5)	Added new support for iOS devices
6)	Added new "About" dialog tab pages for Web & Mobile
7)	Fixed 64 memory calculations
8)	Added new device information in logging feature.
9)	Changed "logging" feature to use AWS as well.



Release 12.1.0 Changes ... January 17, 2013

1)	Added new SMC (System Monitor Console) Window feature
2)	Removed some old WinNT/Win2000 commented out code.
3)	Optimised various code segments for better performance 
4)     	 Replaced the following INI vaules in the "[System]" section. 
    They are no longer PocketBuilder or DBMS specific.
     PB_Check_Version=Y
     DB_Check_Version=Y
     OS_Check_Version=Y


Release 12.1.0 Changes ... May 22, 2012)

1)	Added new INI parameters to control DW buffer Debugging and Memory tracking
2)	Added new code the VS_DC_MASTER user object to allow data buffer introspection
3)	Added new KEY event to the VS_DC_MASTER user object to support Ctrl+Shift+F1 information screen.
4)	Added new WN_INFO_MASTER window to display run time application diagnostics.
5)	Modified the ns_APPL_CONTROLLER_MASTER to support DW buffer introspection and run time information.
6)	Added new KEY event to the WN_MASTER window object to support Ctrl+Shift+F1 information screen.

Release 12.1.0 Changes ... April 10, 2011)

1)	Changed SA database version check to work with SA12.0 as the default.
2)	Extended the "Timing" object base ancestor "ns_timing_master" to
	a) Allow an object to register itself as the Timing object's parent
	b) Fire any event of the parent objects choosing on the timer interval
3)	Added a new gobal function "fn_encrypt_simple" that supports basic encrytion (all written in PowerScript).
4)	Added a new gobal function ""fn_decrypt_simple that supports basic decrytion (all written in PowerScript).
5)	Revised the "fn_open_sheet_window" global function to allow an arragment type option parameter.
6)	Revised the "fn_open_sheet_window_withParm" global function to allow an arragment type option parameter.
7)	Added a new gobal function "fn_convert_packed_decimal" that supports the handling of IBM DB/2 numeric data.
8)	Added a new gobal function "fn_copy_transaction" that alows a new Transaction Object to be created from an active one!
9)	Added a new gobal function "fn_dbms_get_sysdate" that alows you to get the System date of the DBMS server.
10)	Added a new gobal function "fn_lookup_display_value" that gets you the displayed value from any DDDW.
11)	Added a new gobal function "fn_print_screen" that allows you to print any current dialog.
12)	Added a new gobal function "fn_remove_spaces" that allows you to remove ALL spaces from any String variable.
13)	Added a new gobal function "fn_validate_phone_no" that allows you validate any standard phone number.
14)	The gobal function "nc_crypto" was renamed to "nc_crypto_master" to be inline with FC's naming conventions
15)	A new Object "nc_cypher_master" was created that taps into the C++ Cypher and Decypher features
16)	The Application Controller object "nc_app_controller_master" was changed to check for NULL Context values from the OS.
17)	The Application Controller object "nc_app_controller_master" was changed to only log the details of all errors.
	a) user now receives a simple alert witht the option to continue.
	b) user no longer sees the actual error (unless the opne the log in the Log Viewer).
17)	The Application Controller object "nc_app_controller_master" was changed to only log the details of all errors.
18)	The Application Controller object "nc_app_controller_master" was changed to support Processor Affinity.
	a) a New setting �ffinity= setting to the INI file support
	b) New method sets the CPU affinity if the new paramter in the INI file is > 0
19)	The DataWindow control base ancestor "vs_dc_master" was changed to disable moving the control when the Title bar is present.
	Note1: For some reason, this does not work in Winforms.
	Note2: The title bar is not supported in WPF.
20) 	The StaticText extension object "vs_st_transparent_master" was changed to support the PB 12.x implemenation of
	a transparent background colour. 
21)	A new Window ancestor was added (wn_animated_save_master) that supports the new Animated Save feature!
22)	The "wn_master" base ancestor window was changed to implement the Amimated Save feature.
	a) New "of_animation_required" method was added to the Base window class (wn_master) to support Animated saves.
23)	The "wn_master" base ancestor class was changed to change the way duplicate instantiated dialog's were discovered.
	a) This fixes a problem where the Win32 applications toolbars and sheet would seem to "bounce" in the MDI frame.
	b) Corrects a Winform applciation where the lower toolbars would disappear all together until a close/open.
24)	The "wn_master" base ancestor was changed to allow any Window to have a Min or Max size.
25)	The "wn_controller_master" base ancestor was changed to support a "Close All" open sheet/child window option.
26)	The base ancestor menu "mu_master" was changed to implement a new Close All menu under the "Window" pulldown menu item.
27)	The "vs_dc_list_master" DW Control extension ancestor was changed to implement a sortation icon on the heading
	a) uses a triangle drawn on to the heading text.
	b) Triangle direction show the sortation order
	c) If the heading text will interfere with the triangle, it is shifted over slightly.
	d) The shifted heading text is restored upon moving to a new column.
28)	Changed the "wn_popup_master" to centre itself to the current controller window.
	a) Allows better GUI
	b) Supports dual monitors better
29)	Changed the "wn_main_master" to centre itself to the current controller window.
	a) Allows better GUI interface
	b) Better supports a dual monitor PC
	c) Ignores this behaviour of the Controller is an MDI type window
30)	The Application Controller object "nc_app_controller_master" was changed to capture the WebForm (IIs) Session ID
	a) New *private* session ID instance variable added (is_session_id) 
	b) Session ID is written to the Application's LOG file at start-up
	c) A new "of_Get_Session_Id" method was added to expose the private variable to the applciation
31)	The Application Controller object "nc_app_controller_master" was changed to capture the WebForm (IIs) Browser signature!
	a) New *private* instance variable added (is_browser) 
	b) The Browser signature written to the Application's LOG file at start-up
	c) A new "of_get_browser" method was added to expose the current Browser's signature at any time.
32)	The Application Controller object "nc_app_controller_master" was changed to verify that the WebForm browser.
	a) If the Browser is not IE an error message appreas in any browser.
	b) The application will stop on any Web browser other than IE.
33) 	A new global function "fn_build_number" was added to automatically track application builds.
	a) A new INI file was added to support this functionality (STD_FC.ini).
	b) Note: currently code commented out as this crashes the PB 11.5.1 and higher IDE
		Problem reported to Sybase Engineering.
34)	The Order Entry application was changed to
	a) Use the new FlashWindow feature of Response dialogs to alert users visually (Login Dialog)
	b) The Login dialog uses the new simple encryption to save the last good password to the Application's INI file.
	c) The Employee dialog was changed to demonstrate the new fixed DW Control when a title bar is active.
	d) The Employee, Customer and Product list dialogs were changed to demonstrate the new Sort Icon.
35)	Changed SA database version check to work with SA11.0.1.2044
36) 	Updated the core Message DataWindow with new message ID's
37)	Updated the French and Spanish message DW objects for new message transations.
38)	Extended ancedstor "vs_st_transparent_master" changed to support native transparency in PBNative mode.


Release 11.5.1 Changes ... Janaury 5, 2010)

1)	Corrected memory statistics displayed on Help dialog.
2)	Changed SA database version check to work with SA11.0.1
	
Release 11.5.1 Changes ... October 9, 2009)

1)	Corrected size of the Calendar dialog's height.
2)	Added the ability to have a Menu on a Respose dialog.
3) 	Added a new "special effects" datawindow based on animation.
4)	Added new code that recognizes the WPF environment (for migration to PB 12.NET).
5)	Cleaned-up code for better PB 11.5 performance
6)	Added new INI property (Memory=Y/N)
7)	Added the ability to report on memory consumed by DataWindow objects at runtime.
8)	New code added to read the EXE signature. Information now sent to log ...
	Product Name:		xx
	Internal Name:		xx                                                                                                   Product Version:	xx
	File Version:		xx         
	Original File Name:	xx
	File Description:	xx
	Private Build:		xx
	Special Build:		xx
	Company Name:		xx        
	TradeMark:		xx
	Copyright:		xx     
	Comments:		xx
	EXE Location:		xx


Release 11.5.0 Changes ... May 11, 2009)

1)	Corrected size of the Calendar dialog's height calculation.
2)	Added new menu item that activates the MS-Windows screen saver.
3) 	Compiled and tested under EBF - Build 3127

Release 11.2.0 Changes ... Oct 6, 2009)

1)	Added "nc_crypto" NVUO used to interface to Microsoft's Crypto API's
2)	Changed the Calendar base window to make the Clear (Alt+C) and Cancel (ESC) buttons keyboard mapped.
3)	Small various performance and code clean-up!
4)	created an example "Crypto" application to demostrate the Crypto API usage from a PB application.


Release 11.2.0 Changes ... (May 14, 2008)

1)	Various FC components tweaked for PB 11.2.0 and AJAX
2)	"Window" menu now tracks all open sheets in a WebForm application.
3)	"Zoom" dialog now 50% transparent to allow user to see zoomed data through it!
4)	Example "OrderEntry" application enhanced to display .NET logo (if appropriate) at startup.


Release 11.1.0 Changes ... (Nov 16, 2007)

1)	Various FC components tweaked for PB 11.1.0
2)	New "nc_numeric" object added for "Bitwise" operations.
3)	New property added to base "response" dialog to allow it to become resizable!
4)  	Added example of resizable response dialogs to the OrderEntry sample application
	for the application 'Logon'! 
5) 	New instance variables (il_rc and ii_rc) were added to the "base" custom NVUO to allow
	easier development coding without having to define these standard work variables
	in every function and event. 
6) 	New provate instance variable "is_class_name" added to Custome NVUO base that will
	makes it much easier to identify the NVUO during a debugging session.
7)	Added a new "oe_getminmaxinfo" event to the base Window class "wn_master" that monitors
	the allowed maximum and Minimum resizable area of any dialog and holds the dialog to
	those limitations. 
8)	New instance variable "io_owner" added to the base level "nc_master" object that
	tracks the owner (creator) of any NVUO at runtime.
9)	New "of_register" method added to "nc_master" base level that allows the "creator"
	(owner) of any custom nvuo to be registered.
10)	New code added to the existing "oe_post_constructor" event of the "nc_master" base
	level ancestor that forces all creating objects to register themselves. This ensures
	that all custom NVUO's are also descendants of the STD FC's.
 


Release 11.0.0  Changes ... (July 3, 2007)

1)	Conversion to .NET.
2)      Added "Mode" to About dialog to display (Native, Winform or Webform)
3)    	Added WinForm Target and Project
4)	Added WebForm Target and Project
5)	Added SmartClient Target and Project.



Release 10.2.1 Changes ... (Jan. 5, 2006)

1)	Conversion to Unicode.
2)	New Menu generated for the LOg Viewer
3)	Menus fixes added for multi-lingual support.
4)	Controller NVUO updated for PB, ASA and O/S version checks.
5)	Scroll icons scrips updated in Master Menu
6)	Calendar Master updated for TitleBar.


Release 9.0.3A Changes ... (Nov. 20, 2005)

1)	Minor fixes to comply better with PB 9.0.3.
2)	Added transparent Static Text base ancestor
3)	Gradient DataWindow control abstract ancestor added.


Release 9.0.3 Changes ... (August 2005)

1)	Initial Conversion of PocketBuilder FC's to PowerBuilder!
2)	Added a "of_send_mail" method to the application controller. This allows MAPI
	requestes to be sent from PB.
	


======================================== END ============================================