Software Tool & Die Inc
EAServer PowerBuilder Foundation Classes

=================================  HISTORY   ==============================
Release 1.0.0 	- January  20, 2003  (initial release PB 8/9)
Release 10.2.1 	- December 24, 2006
Release 10.5.1 	- January   1, 2007
Release 11.0.1	- July     15, 2007
Release 11.2.0	- May 	   12, 2008
Release 11.5.0  - February 26, 2009
Release 11.5.2  - October   9, 2009
Release 12.0.0  - November  4, 2009 (PB beta)
Release 12.1.0  - December  2, 2010

=================================  FORWARD   ==============================

(STD PB FC)

 All Developers;

	Welcome to the the Software Tool & Die (STD) EAServer web development enhancement Foundation Classes (FC) for PowerBuilder (PB). This is a set of "intelligent" ancestor objects for PB release 10.2.1 (build 9004) and higher! The FC's have been designed over a period of months. They are presented here as "freeware" (please see the enclosed STD General license Agreement) and on an "as is" basis. The STD EAS FC's are a port of the PocketBuilder compliment originally designed for the PocketPC and a hybrid adaptation of Web.PB and ASP/ASP.net alignment. The interesting thing about these classes is the "small" footprint and exceptional speed at which it operates. On one EAServer, where every CPU cycle is precious, the FC's have proven heir worth. Now you can enjoy a "Light" version of the PFC without the heavy learning curve or high compile overhead. The STD EAS FC's will compile to around 500K (PBD form) compared to nearly 12M for the Sybase PFC's which can not even be used within EAServer!
 
	The STD EAS FC's represent a significant enhancement to the way a PB developer works (productivity), the capabilities of PB, and optimization/leverage of the EASever (Application Server) System. These FC's were developed with the PowerBuilder (PB) PFC in mind, but ... have been made easier to use, more efficient (less overhead), more intuitive, parameter driven and more "Object Oriented". Initial testing with one EAServer has shown this architecture can easily support 1,000 sessions  minute or more!

	Each release of the STD EAS FC's is geared to it's equivalent PB release! In each PB release there are significant changes. For example HTML rendring of web pages and run time behavior between Build nnnn to Build xxxx,  that we would recommend ONLY using this version of the STD EAS FC's with your EAS/PB Build! If you want to use the FC's with a lower Build number, you may experience some weird "real estate" scenarios. These will have to be adjusted for when you migrate to your production build version. But, if do not mind that, it should be a minor realignment effort.

	The STD Fc's come with a "WorkSpace", "Target" and dummy "Application Object". These have been provided to allow you regenerate the objects. It is expected that the EAS/PB developer will use this set of BASE and ABSTRACT ancestor objects for their new application development. To keep the FC overhead small, it is expected that the PPB developer will copy and RENAME the FC library to their own project. For example: if you were developing a Help Desk System you might copy the "STD_PB_Base.pbl" and rename it to "HDS_Base.pbl". Then treat the objects in "HDS_Base.pbl" as you would the "PFE" layer of the PB PFC. This "HDS_Base.pbl" should compile into a ".PKD" file of about 500K which compliments the any device with a small foot print!

	I have not had the extensive time to document the STD FC's objects other that in the "oe_Documentation" events and throughout the general code. So please review these areas fully to understand the object(s) behavior. We would recommend also downloading the sample "eStore" application built from the STD FC's, as another aid in assimilating the FC learning curve. Both the STD FC's and the "eStore" system will be enhanced together to reflect the intended use of the Base / Abstract classes.

	From the GUI point of view, the STD FC's can be used to build any JSP, ASP, PHP, CFM, etc web applciation basing the lofic and HTML generation on Sybase "Web" DataWindow technology. From the various demonstration applications, you will see the ability to build.
	
	Since this FC was developed in Canada's National capital, it was architected to support multiple languages. Of course Canada supports either French or English, but the STD FC's were built to support any combination of languages, either now or in the future. The general approach is "static" language switching (where the user picks the language at "logon" time). In the future, the STD FC's will be "dynamic" language capable as well. But due to the compressed development time frames, this was not coded for version 1.0.

	STD would like to recognize it's Alpha and Beta testers for the STD FC's. his has now included five major Canadian Government Departments and numerous private corporations around North America. In particular, STD would like to recognize Austin Philips for his early use, adoption and example code. This has led to a more polished 1st release of the FC's. It is hoped that as other various parties develop code using the STD FC's or, PB developers have functional requirements not yet supported, they will funnel these back to the author for inclusion in the next release!


	This marks a mile stone for me as an original Beta tester on PB release 0.8 (Nov 1989) to PB 10.5.x and now 11.x in 2007 without missing a Beta cycle. Please enjoy the STD EAS FC's for PB. I hope you find them as fun to use as I had in building them! 


Regards;

Chris Pollach (Author STD FC's)
President - Software Tool & Die Inc.
aka: Great White North Technical Evangelist ("Power" ON!)
e-Mail:	CPOLLACH@Travel-Net.com
Web Site: http://www.travel-net.com/~cpollach
Blog:	http://ChrisPollach.pbdjmagazine.com


=================================  CHANGE DETAIL HISTORY   ==============================


Release 12.1.0 Changes ... Dec. 2, 2010)

1)	Conversion to PowerBuilder 12.1.0 (Build 6518 - MR).
2)	Tested with EAS version 5.5 and 6.3.

Release 11.5.1 Changes ... Nov. 4, 2009)

1)	Conversion to PowerBuilder 12.0.0 (Build 4507 - Beta2).
2)	EAS 6.3 testing

Release 11.5.1 Changes ... Oct. 9, 2009)

1)	Conversion to PowerBuilder 11.5.1 (Build 4011).
2)	Tested with EAS v6.2 and 6.3


Release 11.5.0 Changes ... Feb 26, 2009)

1)	Conversion to PowerBuilder 11.5.0 (Build 3127).
2)	InLine code documentation updates.
3)	Tested with EAServer 5.5
4)	Web Target dropped as its not supported in PB 11.5
5)	Upgraded to work with SQLAnyWhere version 11.0
6)	Example "eStore" application cleaned up.


Release 11.2.0 Changes ... May 12, 2008)

1)	Conversion to PowerBuilder 11.2.0 (GA).
2)	InLine code documentation updates.
3)	Tested with EAServer 5.5


Release 11.0.0 Changes ... July 15, 2007)

1)	Conversion to PowerBuilder 11.0.0 (GA).
2)	InLine code documentation updates.
3)	Tested with EAServer 5.5
4) 	Added "CanBePooled" event to "EAS Master" Ancestor for error recovery


Release 10.5.1 Changes ... January 2, 2007)

1)	Conversion to PowerBuilder 10.5.1 (GA).
2)	InLine code documentation updates.
3)	Tested with EAServer 5.2, 5.3 and 5.5


Release 10.2.1 Changes ... (December 18, 2006)

1)	Conversion to Unicode.
2)	InLine code documentation updates.
3)	Tested with EAServer 5.2, 5.3 and 5.5

======================================== END ============================================