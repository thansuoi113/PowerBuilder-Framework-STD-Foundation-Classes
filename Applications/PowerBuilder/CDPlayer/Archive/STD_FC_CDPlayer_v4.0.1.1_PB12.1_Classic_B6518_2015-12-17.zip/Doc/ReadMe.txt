
 **  Welcome to the PowerBuilder CD player (release  4.0.0.1)  **

	This release is written in PowerBuilder 12.1 (build 6518 - GA) and encompasses some interesting features that you can coax out of the Windows operating system. Release 4.0.0.1 is released as of July 20, 2015 and replaces release 3.4.6 from PB 11.2 and 3.4.2 from PB 11.0.


 New/Enhanced features in V4.0.0.1:

1) Ported the code base to PB 12.1 Classic - Build 6518.
2) Added STD Integrated Foundation Class framework.
3) Refactored the entire application to use STD Framework!
4) Added more StarWars sounds!


 New/Enhanced features in V3.4.6.1:

1) Ported the code base to PB 12.0 Classic
2) Added WPF support code for PB 12.NET
3) Cleaned up menu accelerators for WPF
4) Tested with Vista SP2 and Windwos 7 GA
5) Added code to verify the PB Run time version


 New/Enhanced features in V3.4.6:

1) Updated menu look and feel for PB 11.5
   - New icon for "Pause" feature.
2) Changed the SDK calls for 100% Unicode compliance
3) Added new DataWindow animation in the "Spash" screen
   - Uses PB 11.5 DW gradiants!
4) Added new button at the bottom centre of the player
   -  Allows the user to expand or contract the dialog
5) Added "Fractal display while music is playing
   - See change #4
6) Changed the code to comply with Vista SP1
7) Added "Volume Mixer" support for Vista
   - When opened from Player - Mixer has its own CDPlayer column!
8) Added Starwars effects to "Pause" and "Close"



 New/Enhanced features in V3.4.4:

1) Recompiled for compliance to PB 11.2


 New/Enhanced features in V3.4.2:

1) Updated menu look and feel for PB 11.0
2) Can compile to a .Net Winform.
3) Can compile for deploymnet as a Smart Client
4) Spash and About screens show "mode" (.Net / Native)
5) Fix added to stop duplicate Volume Control dialog.
6) CD player closes Volume Control upon close if still open.



 New/Enhanced features in V3.2.1:

1) Updated menu look and feel for PB 10.5


Enjoy

Chris Pollach
President: Software Tool & Die Inc.
cpollach@travel-net.com

