Software Tool & Die Inc
PowerBuilder Utility

=================================  HISTORY   ==============================
Release 9.0.3A 	- November 20, 2005
Release 10.2.1 	- January   4, 2007
Release 11.2.0  - November 23, 2009
Release 11.5.1  - November 23, 2009
Release 12.0.0  - May      19, 2010

=================================  FORWARD   ==============================

(STD SQLXtract)

 All ;

    Welcome to Software Tool & Die�s (STD) Inc. SQL Extraction utility for PowerBuilder�. This utility was developed with the anticipation that many PowerBuilder� sites use Sybase�s DataWindow� technology to gain access to various DataBase Management Systems. The DataWindow however, stores its SQL in a non-DBMS vendor specific format. This does not allow various SQL database analysis products access to the various DW SQL statements for processing.

    It is the design of this utility to provide a bridge between the PowerBuilder environment and products like SQLExpert� or Quest-Central� SQL tuning environments by reverse engineering the SQL out of the DataWindow object and into a common text file that can be easily analyzed by various products.

    This utility will work on PowerBuilder, PocketBuilder, InfoMaker, WorkSpace and DataWindow.Net libraries!



Regards;

Chris Pollach (Author STD FC's)
President - Software Tool & Die Inc.
aka: Great White North Technical Evangelist ("Power" ON!)
e-Mail:	CPOLLACH@Travel-Net.com
Web Site: http://www.travel-net.com/~cpollach
Blog:	http://ChrisPollach.pbdjmagazine.com


=================================  CHANGE DETAIL HISTORY   ==============================

Release 12.0.0 Changes ... May 19, 2010)

1)	Conversion to PB 12.0.0 - build 5530.
2)	Tested with SA 11.01 and test DB "EAS Demo DB V120"

Release 11.5.1 Changes ... (Nov. 23, 2009)

1)	Conversion to PB 11.5.1 - build 4011.
2)	Tested with SA 11, SS2008, O10/O11g and ASE 15.3 DBMS.
3)	Converted MENU objects to new style
4)	Added menu animation
5)	Added toolbar animation
6)	Cleaned-up toolbar icons.
7)	Added support for Oracle 11g
8)  	Added support for SQLServer SNC (SQLServer Native Client)
	SS2005 and SS2008
9)	Removed support for Oracle 8i


Release 11.2.0 Changes ... (Nov. 23, 2009)

1)	Conversion to PB 11.2.
2)	Tested with SA 10, SS2005 and ASE 15.0 DBMS.


Release 10.2.1 Changes ... (Jan. 4, 2007)

1)	Conversion to Unicode.
2)	Fix added to maintain original folder where the utility was launched from.
3)	Oracle version 7 and 8.0 DB driver support dropped.
4)	Oracle 8.0.4, 9i, and 10g DB support added.
5)	Microsoft SQLServer native driver (ANSI) dropped.
6)	Microsoft SQLServer OLE-DB and ADO.Net Unicode driver support added for SS2005.
7)	Sybase ASE Open CLient "release number" added to support new ASE version 15.x 



Release 9.0.3 Changes ... (August 2005)

1)	Initial Construction of this utility!

	


======================================== END ============================================