
public class HelloWorld {

    public HelloWorld () {  }

    public static String sayHello(){
        return "Hello world";
    }

    public String sayNonStaticHello(){
        return "Hello world";
    }    

    public static void main (String[] args) {
        System.out.println(HelloWorld.sayHello());
    }

}
