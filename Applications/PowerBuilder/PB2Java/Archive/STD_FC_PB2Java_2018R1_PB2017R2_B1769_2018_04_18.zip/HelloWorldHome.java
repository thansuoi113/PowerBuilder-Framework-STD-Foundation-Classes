
public interface HelloWorldHome { }
