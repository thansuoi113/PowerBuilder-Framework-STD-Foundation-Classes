
   Note that the 64bit app will NOT work because Appeon does not have a 64bit version of the "pbejbclient170.pbd" file in its deployment libray located at "C:\Program Files (x86)\Appeon\Shared\PowerBuilder\x64"!

   Thus a bug in PB 2017R2.
