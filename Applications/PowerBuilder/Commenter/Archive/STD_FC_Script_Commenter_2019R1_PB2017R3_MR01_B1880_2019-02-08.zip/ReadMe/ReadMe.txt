Software Tool & Die Inc
Code Commenter

=================================  HISTORY   ==============================
Release 2019.2.0.021 - January 08, 2019 GA     - Major Release  (2019R1)
Release 2018.2.0.019 - October 29, 2018 GA     - Major Release  (2017R2)
Release 2018.1.0.018 - April 03, 2018 GA       - Major Release  (2017R1) 
Release 2017.2.0.015 - August 17, 2017 GA      - Major Release  (2017R2) 
Release 2017.1.0.011 - January 2, 2017 GA      - Major Release  (2017R1) 

=================================  FORWARD   ==============================

(STD Commenter)

 All Developers;

	Welcome to the the Software Tool & Die (STD) Code Commenter for PowerBuilder (PB) Classic. This application will insert either a code comment header or a block comment into any open PowerScript current painter. The original code was developed by RC SIZER and adopted to the STD framework.

 	The STD Code Commenter is a significant enhancement to the way a PB developer works (productivity) by easily allowing code comments to be added to any object classes PowerScipt!

	The latest release ofr the Code Commenter application is designed to work with any Unicode version of PowerBuilder (v10.0 through 2017). It can be activated in any PB IDE by creating a toolbar short-cut icon and assigning to the the EXE as follows:

<path>\ScriptCommenter.exe  header
  - or -
<path>\ScriptCommenter.exe  block
  - or -
<path>\ScriptCommenter.exe  inline

	The values added as a header or block comment are located in the "Comment_Block.ini" file. This file is built based on the values found in the "Comment_Template.ini" file.

Regards;
Chris Pollach (Author STD FC's)
aka: Great White North Technical Evangelist (have you hugged your "DataWindow" today?)
President - Software Tool & Die Inc.
e-Mail:	Chris.Pollach@ncf.ca
Website:  http://www.softdie.ca
Blog: http://chrispollach.blogspot.com
PBDJ: http://chrispollach.sys-con.com
SourceForge: http://sourceforge.net/projects/stdfndclass


=================================  CHANGE DETAIL HISTORY   ==============================

Release 2019.1.0.22 Major Release (2019R1) ... February 8, 2019 (GA) PB2017R3 MR01 Build 1880
1)	Migrated the App code from PB2017R3 build 1858 to PB2017R3 MR01 build 1880
2) 	Replaced STD Integrated Framework from v2018.4.0.112 to v2019.1.0.124
3) 	Added code to support the new PB2018 & PB2019 IDE's


Release 2018.1.0.19 Major Release (2017R3) ... April 3, 2018 (GA) PB 2017 Build 1858
1)	Migrated the App code from PB 2017 build 1769 to PB 2017 build 1858
2) 	Replaced STD Integrated Framework from v2018.2.0.97 to v2018.4.0.112

Release 2018.1.0.18 Major Release (2017R2) ... April 3, 2018 (GA) PB 2017 Build 1769
1)	Migrated the App code from PB 2017 build 1666  to PB 2017 build 1769


Release 2017.1.0.15 Major Release (2017R0) ... August 15, 2017 (GA) PB 2017 Build 1666
1)	Migrated the App code from PB 12.1.x to PB 2017 build 1666
2) 	Optimized the code that searches for the IDE frame window.
3) 	Created new Project objects for 32bit & 64bit deployment
4) 	Updated the STD framework to release 2017.2.0.76 (2017R2) ... July 17, 2017


Release 2016.1.0.11 Major Release (2017R0) ... January 2, 2017 (GA) PB 12.1.0 Build 6518
1)	Refactored the original code commenter to the STD framework and completed the Unicode conversion.

======================================== END ============================================