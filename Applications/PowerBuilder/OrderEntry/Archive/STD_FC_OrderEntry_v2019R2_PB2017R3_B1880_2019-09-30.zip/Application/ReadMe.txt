
   For the RTE checking logic to work via the latest STD Integrated Framework in PB2017R3 MR01 (build 1880) and higher (ie:PB2019), you need to add the following code to your Application Object's source code, as follows:


forward prototypes
public function string of_get_rte_key ()
public function long of_get_rte_type ()
public function long of_get_rte_version ()
end prototypes

public function string of_get_rte_key ();
Return 	richtexteditkey						// Return value to caller
end function

public function long of_get_rte_type ();
Return	richtextedittype					// Return value to caller
end function

public function long of_get_rte_version ();
Return 	richtexteditversion					// Return value to caller
end function



Steps:
1) Edit your Application Object's source
2) Locate the source line ...
   on <YourAppName>.create
3) Paste the above code *before* that create statement
4) Save your Aplication Source back to its PBL

