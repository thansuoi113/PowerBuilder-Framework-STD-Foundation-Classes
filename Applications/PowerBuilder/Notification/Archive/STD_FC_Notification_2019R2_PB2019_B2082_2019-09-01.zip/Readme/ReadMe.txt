
   To use the MS-Windows PBNotify application, run the EXE and pass in the following commandline ...

pbnotify32p.exe Time=nn,Name=xxxxxxx,Msg=xxxxxx

Where ...

Time=nn		// Seconds
Name=xxxx	// Application Name
Msg=xxxx	// User message to display

Note1: The application returns an O/S return code. +1 for OK and -1 for fail.
Note2: The application will only work in MS-Windows 10 and higher
Note3: Can be called from any Application EXE, Batch, PowerShell or Windows scheduler script!
Note4: Simultaneous messages can appear if the Application Name or message text is different.


