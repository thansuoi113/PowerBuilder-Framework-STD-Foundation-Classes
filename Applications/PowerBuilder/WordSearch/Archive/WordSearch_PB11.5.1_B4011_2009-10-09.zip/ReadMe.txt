
  Word Search Puzzle Generator

  Welcome to the "Word Search" puzzle generator. This utility as designed to aid in the generation of a word search puzzle, which can be very time consuming to the puzzle creator from the point of layout and then finally randomly filling in the empty spaces with letters. This PowerBuilder program was built to assist in the electronic development of such puzzles.

  To install the Word Search puzzle assistant, just copy the executable that can be generate from either of the two "project" objects in the first library to the intended users machine. You may also have to copy the PowerBuilder run time support files as well if they are not present on the target machine. Then, edit the "WordSearch.ini" file. It contains the name of the person developing the word search puzzle. Edit the INI file to identify the puzzle creator�s name. This will appear on the final output.

  To build a "new" word search puzzle, use the following steps:

1) Start the Word Search puzzle generator.
2) Enter your various words both horizontally and vertically into the empty form.
3) Check the word spellings as you go along.
4) You may save the Word Search puzzle at any time using the Save icon on the toolbar or, by using the File => Save menu option.
5) Once all the various words are entered in the puzzle, use the "Fill" icon on the toolbar to have the puzzle generator complete the puzzle form with random letters.
6) Select the Print Setup icon to direct the final puzzle output to the target printer or PDF generator.
7) Use the "print" icon to print a final copy of the word search puzzle.

  To resume building a word search puzzle, use the following steps:

1) Start the Word Search puzzle generator.
2) Use the "Open" icon on the toolbar to reload your work from the last "save" point.
3) Complete steps 2-7 in the "Build a New Word Search" section above.

Note: You may save your work, exit and come back to the puzzle at any time!

Regards ... Chris Pollach (Author)
President: Software Tool & Die Inc.


